# NNDM validation implementation

The repository uses prediction-domain-oriented nearest-neighbour distance matching (NNDM) only after the feature configuration has been fixed. Conventional LOOCV is used earlier for final feature-subset determination and the TN ablation analyses.

## Manuscript settings

- Target prediction domain: 10,343 valid bare-soil ROI-grid centres
- Grid spacing: 0.30 m
- Matching parameter: `phi = max`
- Minimum retained training proportion: `0.5`
- TN sample number: 50
- Mean retained training number: 48.86
- Minimum retained training number: 46

## Reproduction modes

### Archived fold plan

`data/reproducibility_current/nndm_folds_current.csv` contains anonymised fold membership derived from the undistributed RTK coordinates and common prediction grid. It allows exact reproduction of the manuscript TN validation without releasing identifiable spatial data.

### New spatial dataset

For a new dataset, `scripts/nndm_validation.py` generates folds directly from sample coordinates and target prediction locations. Both coordinate sets must use the same projected coordinate system and metre units.

## Use in the workflow

The validation sequence follows the manuscript:

1. random five-fold cross-validation for preliminary feature screening and narrowing of candidate hyperparameter ranges;
2. conventional LOOCV for final feature-subset determination and TN Raw–CleanV, ROI-scale, and feature-category ablations;
3. after the feature configuration is fixed, NNDM for algorithm and shortlisted hyperparameter comparison, final model selection, and primary spatial-performance reporting;
4. repeated ten-fold cross-validation only as a complementary sensitivity analysis.

The archived NNDM fold plan is therefore not used by `02_feature_screening_selection.py`; it is introduced in `03_model_training_and_comparison.py` and retained for the final-model reproduction scripts.
