# -*- coding: utf-8 -*-
"""Prediction-domain-oriented nearest-neighbour distance matching (NNDM).

This module provides two reproducible validation modes:

1. Generate NNDM folds from projected sample coordinates and a target
   prediction grid using a pure-Python implementation of the geographic
   branch of CAST::nndm.
2. Load an archived fold plan. This is used by the compact anonymised TN
   reproduction because raw RTK coordinates and the full prediction grid are
   not distributed.

Coordinates used to generate new folds must share the same projected CRS and
must be expressed in metres. No rotation, scaling, or implicit registration is
performed by this module.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, List, Mapping, Optional, Sequence, Tuple, Union

import numpy as np
import pandas as pd
from scipy.spatial import cKDTree
from scipy.spatial.distance import cdist
from scipy.stats import wasserstein_distance


@dataclass
class NNDMResult:
    train_indices: List[np.ndarray]
    test_indices: List[np.ndarray]
    exclude_indices: List[np.ndarray]
    prediction_distances: np.ndarray
    ordinary_loo_distances: np.ndarray
    matched_validation_distances: np.ndarray
    phi: float
    min_train: float
    removed_links: int
    iteration_n: int


def read_table(path: str | Path) -> pd.DataFrame:
    path = Path(path)
    if path.suffix.lower() in {".xlsx", ".xls"}:
        return pd.read_excel(path)
    for encoding in ("utf-8-sig", "utf-8", "gbk"):
        try:
            return pd.read_csv(path, encoding=encoding)
        except Exception:
            continue
    return pd.read_csv(path)


def resolve_path(root: Path, value: str | Path) -> Path:
    path = Path(value)
    return path if path.is_absolute() else root / path


def _safe_row_nanmin(matrix: np.ndarray) -> np.ndarray:
    bad = np.where(np.all(np.isnan(matrix), axis=1))[0]
    if len(bad):
        raise RuntimeError(
            "NNDM produced validation samples without any retained training "
            f"observations: {bad.tolist()}"
        )
    return np.nanmin(matrix, axis=1)


def nndm_exact_python(
    sample_xy: np.ndarray,
    prediction_xy: np.ndarray,
    phi: Union[str, float] = "max",
    min_train: float = 0.5,
    tolerance: float = 1e-12,
) -> NNDMResult:
    """Generate NNDM folds for a spatial prediction domain.

    Parameters
    ----------
    sample_xy:
        ``n x 2`` projected sample coordinates in metres.
    prediction_xy:
        ``m x 2`` target prediction locations in the same coordinate system.
    phi:
        ``"max"`` or a non-negative distance threshold.
    min_train:
        Minimum proportion of observations retained for training in each fold.
    """
    sample_xy = np.asarray(sample_xy, dtype=float)
    prediction_xy = np.asarray(prediction_xy, dtype=float)
    if sample_xy.ndim != 2 or sample_xy.shape[1] != 2:
        raise ValueError("sample_xy must be an n x 2 array.")
    if prediction_xy.ndim != 2 or prediction_xy.shape[1] != 2:
        raise ValueError("prediction_xy must be an m x 2 array.")
    if len(sample_xy) < 3 or len(prediction_xy) < 1:
        raise ValueError("NNDM requires at least three samples and one prediction location.")
    if not np.all(np.isfinite(sample_xy)) or not np.all(np.isfinite(prediction_xy)):
        raise ValueError("Sample and prediction coordinates must be finite.")
    if not 0.0 <= float(min_train) <= 1.0:
        raise ValueError("min_train must be between 0 and 1.")

    prediction_distances = cKDTree(sample_xy).query(prediction_xy, k=1)[0].astype(float)
    pairwise = cdist(sample_xy, sample_xy, metric="euclidean").astype(float)
    np.fill_diagonal(pairwise, np.nan)
    ordinary_distances = _safe_row_nanmin(pairwise)
    matched_distances = ordinary_distances.copy()

    if isinstance(phi, str):
        if phi.lower() != "max":
            raise ValueError("A string phi value must be 'max'.")
        phi_value = float(
            max(np.max(prediction_distances), np.nanmax(pairwise)) + 1e-9
        )
    else:
        phi_value = float(phi)
        if phi_value < 0:
            raise ValueError("phi must be non-negative.")

    rmin = float(np.min(matched_distances))
    jmin = int(np.where(np.isclose(matched_distances, rmin, atol=tolerance, rtol=0))[0][0])
    kmin = np.where(
        np.isclose(pairwise[jmin], rmin, atol=tolerance, rtol=0, equal_nan=False)
    )[0]
    removed_links = 0
    iteration_n = 0
    max_iterations = len(sample_xy) * len(sample_xy) * 4

    while rmin <= phi_value + tolerance:
        iteration_n += 1
        if iteration_n > max_iterations:
            raise RuntimeError("NNDM exceeded the safe iteration limit.")

        cv_ecdf_before_current = (
            np.sum(matched_distances <= rmin + tolerance) - 1
        ) / len(matched_distances)
        prediction_ecdf = np.mean(prediction_distances <= rmin + tolerance)
        available_proportion = np.sum(np.isfinite(pairwise[jmin])) / pairwise.shape[1]
        should_remove = (
            cv_ecdf_before_current >= prediction_ecdf - tolerance
            and available_proportion > min_train + tolerance
            and len(kmin) > 0
        )

        if should_remove:
            pairwise[jmin, kmin] = np.nan
            removed_links += int(len(kmin))
            matched_distances = _safe_row_nanmin(pairwise)
            candidates = matched_distances[matched_distances >= rmin - tolerance]
            if len(candidates) == 0:
                break
            rmin = float(np.min(candidates))
        else:
            next_values = matched_distances[matched_distances > rmin + tolerance]
            if len(next_values) == 0:
                break
            rmin = float(np.min(next_values))

        jmin = int(
            np.where(np.isclose(matched_distances, rmin, atol=tolerance, rtol=0))[0][0]
        )
        kmin = np.where(
            np.isclose(pairwise[jmin], rmin, atol=tolerance, rtol=0, equal_nan=False)
        )[0]

    all_indices = np.arange(len(sample_xy))
    train_indices: List[np.ndarray] = []
    test_indices: List[np.ndarray] = []
    exclude_indices: List[np.ndarray] = []
    for test_index in range(len(sample_xy)):
        train = np.where(np.isfinite(pairwise[test_index]))[0].astype(int)
        excluded = all_indices[np.isnan(pairwise[test_index])]
        excluded = excluded[excluded != test_index].astype(int)
        train_indices.append(train)
        test_indices.append(np.asarray([test_index], dtype=int))
        exclude_indices.append(excluded)

    return NNDMResult(
        train_indices=train_indices,
        test_indices=test_indices,
        exclude_indices=exclude_indices,
        prediction_distances=prediction_distances,
        ordinary_loo_distances=ordinary_distances,
        matched_validation_distances=matched_distances,
        phi=phi_value,
        min_train=float(min_train),
        removed_links=removed_links,
        iteration_n=iteration_n,
    )


def _split_ids(value: object) -> List[str]:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return []
    return [item.strip() for item in str(value).split(";") if item.strip()]


def load_fold_plan(
    path: str | Path,
    sample_ids: Sequence[str],
) -> Tuple[List[Tuple[np.ndarray, np.ndarray]], pd.DataFrame]:
    """Load and validate an archived NNDM fold plan."""
    plan = read_table(path).sort_values("Fold_ID").reset_index(drop=True)
    required = {"Fold_ID", "Test_Sample_ID"}
    missing = required.difference(plan.columns)
    if missing:
        raise ValueError(f"Fold plan is missing columns: {sorted(missing)}")

    ids = [str(value) for value in sample_ids]
    id_to_index = {value: index for index, value in enumerate(ids)}
    if len(id_to_index) != len(ids):
        raise ValueError("Sample IDs must be unique before loading an NNDM fold plan.")

    splits: List[Tuple[np.ndarray, np.ndarray]] = []
    seen_tests: List[str] = []
    normalized_rows = []
    for _, row in plan.iterrows():
        test_ids = _split_ids(row["Test_Sample_ID"])
        if len(test_ids) != 1:
            raise ValueError("Each archived NNDM fold must contain one test sample.")
        test_id = test_ids[0]
        if test_id not in id_to_index:
            raise ValueError(f"Fold-plan test sample is absent from the modelling table: {test_id}")

        if "Train_Sample_IDs" in plan.columns and _split_ids(row.get("Train_Sample_IDs")):
            train_ids = _split_ids(row.get("Train_Sample_IDs"))
        else:
            excluded_ids = set(_split_ids(row.get("Excluded_Sample_IDs")))
            train_ids = [value for value in ids if value != test_id and value not in excluded_ids]

        unknown = [value for value in train_ids if value not in id_to_index]
        if unknown:
            raise ValueError(f"Fold plan contains unknown training samples: {unknown}")
        if test_id in train_ids:
            raise ValueError(f"Test sample also appears in training data: {test_id}")

        train_idx = np.asarray([id_to_index[value] for value in train_ids], dtype=int)
        test_idx = np.asarray([id_to_index[test_id]], dtype=int)
        splits.append((train_idx, test_idx))
        seen_tests.append(test_id)
        normalized_rows.append(
            {
                "Fold_ID": int(row["Fold_ID"]),
                "Test_Sample_ID": test_id,
                "Train_Sample_IDs": ";".join(train_ids),
                "Excluded_Sample_IDs": str(row.get("Excluded_Sample_IDs", "") or ""),
                "Train_N": int(len(train_idx)),
                "Test_N": 1,
                "Excluded_N": int(len(ids) - len(train_idx) - 1),
            }
        )

    if sorted(seen_tests) != sorted(ids):
        missing_tests = sorted(set(ids).difference(seen_tests))
        duplicate_tests = sorted({value for value in seen_tests if seen_tests.count(value) > 1})
        raise ValueError(
            "Archived fold plan must test every sample exactly once. "
            f"Missing={missing_tests}; duplicates={duplicate_tests}"
        )
    return splits, pd.DataFrame(normalized_rows)


def save_fold_plan(
    path: str | Path,
    sample_ids: Sequence[str],
    result: NNDMResult,
) -> pd.DataFrame:
    ids = np.asarray([str(value) for value in sample_ids], dtype=object)
    rows = []
    for fold_id, (train, test, excluded) in enumerate(
        zip(result.train_indices, result.test_indices, result.exclude_indices), start=1
    ):
        rows.append(
            {
                "Fold_ID": fold_id,
                "Test_Sample_ID": ";".join(ids[test].tolist()),
                "Train_Sample_IDs": ";".join(ids[train].tolist()),
                "Excluded_Sample_IDs": ";".join(ids[excluded].tolist()),
                "Train_N": int(len(train)),
                "Test_N": int(len(test)),
                "Excluded_N": int(len(excluded)),
                "Validation_Method": "Prediction-domain-oriented NNDM spatial validation",
            }
        )
    table = pd.DataFrame(rows)
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    table.to_csv(path, index=False, encoding="utf-8-sig")
    return table


def coordinate_diagnostics(result: NNDMResult) -> Mapping[str, float]:
    return {
        "prediction_point_n": int(len(result.prediction_distances)),
        "phi_distance_m": float(result.phi),
        "min_train_proportion": float(result.min_train),
        "removed_directed_links": int(result.removed_links),
        "algorithm_iterations": int(result.iteration_n),
        "prediction_nnd_median_m": float(np.median(result.prediction_distances)),
        "ordinary_loo_nnd_median_m": float(np.median(result.ordinary_loo_distances)),
        "nndm_validation_distance_median_m": float(
            np.median(result.matched_validation_distances)
        ),
        "wasserstein_ordinary_loo_m": float(
            wasserstein_distance(result.prediction_distances, result.ordinary_loo_distances)
        ),
        "wasserstein_nndm_m": float(
            wasserstein_distance(
                result.prediction_distances, result.matched_validation_distances
            )
        ),
    }


def generate_folds_from_tables(
    sample_table: pd.DataFrame,
    prediction_table: pd.DataFrame,
    sample_ids: Sequence[str],
    sample_id_col: str,
    sample_x_col: str,
    sample_y_col: str,
    prediction_x_col: str,
    prediction_y_col: str,
    phi: Union[str, float] = "max",
    min_train: float = 0.5,
) -> NNDMResult:
    coordinates = sample_table.copy()
    coordinates[sample_id_col] = coordinates[sample_id_col].astype(str)
    coordinates = coordinates.set_index(sample_id_col)
    missing = [str(value) for value in sample_ids if str(value) not in coordinates.index]
    if missing:
        raise ValueError(f"Sample-coordinate table is missing IDs: {missing}")
    sample_xy = coordinates.loc[
        [str(value) for value in sample_ids], [sample_x_col, sample_y_col]
    ].apply(pd.to_numeric, errors="coerce").to_numpy(float)
    prediction_xy = prediction_table[[prediction_x_col, prediction_y_col]].apply(
        pd.to_numeric, errors="coerce"
    ).dropna().to_numpy(float)
    return nndm_exact_python(sample_xy, prediction_xy, phi=phi, min_train=min_train)


def resolve_nndm_splits(
    config: Mapping,
    root: Path,
    sample_ids: Sequence[str],
) -> Tuple[List[Tuple[np.ndarray, np.ndarray]], pd.DataFrame, Mapping[str, object]]:
    """Resolve archived folds or generate folds from spatial coordinates."""
    settings = dict(config.get("validation", {}))
    fold_plan_value = settings.get("fold_plan_csv")
    prefer_fold_plan = bool(settings.get("prefer_archived_fold_plan", True))
    if fold_plan_value:
        fold_plan_path = resolve_path(root, fold_plan_value)
        if fold_plan_path.exists() and prefer_fold_plan:
            splits, plan = load_fold_plan(fold_plan_path, sample_ids)
            return splits, plan, {
                "source": "archived_fold_plan",
                "fold_plan": str(fold_plan_path),
                "method": "Prediction-domain-oriented NNDM spatial validation",
            }

    sample_value = settings.get("sample_coordinates") or config.get("paths", {}).get("sample_points")
    prediction_value = settings.get("prediction_grid")
    if not sample_value or not prediction_value:
        raise ValueError(
            "NNDM requires either validation.fold_plan_csv or both "
            "validation.sample_coordinates and validation.prediction_grid."
        )
    sample_path = resolve_path(root, sample_value)
    prediction_path = resolve_path(root, prediction_value)
    if not sample_path.exists() or not prediction_path.exists():
        raise FileNotFoundError(
            f"NNDM spatial inputs not found: sample={sample_path}; prediction={prediction_path}"
        )

    sample_table = read_table(sample_path)
    prediction_table = read_table(prediction_path)
    columns = config.get("columns", {})
    result = generate_folds_from_tables(
        sample_table=sample_table,
        prediction_table=prediction_table,
        sample_ids=sample_ids,
        sample_id_col=settings.get("sample_id_col", columns.get("sample_id", "Sample_ID")),
        sample_x_col=settings.get("sample_x_col", columns.get("easting", "Easting")),
        sample_y_col=settings.get("sample_y_col", columns.get("northing", "Northing")),
        prediction_x_col=settings.get("prediction_x_col", "Easting"),
        prediction_y_col=settings.get("prediction_y_col", "Northing"),
        phi=settings.get("phi", "max"),
        min_train=float(settings.get("min_train", 0.5)),
    )
    output_dir = resolve_path(root, config.get("paths", {}).get("output_dir", "outputs")) / "validation"
    output_dir.mkdir(parents=True, exist_ok=True)
    plan = save_fold_plan(output_dir / "nndm_folds.csv", sample_ids, result)
    diagnostics = coordinate_diagnostics(result)
    with (output_dir / "nndm_distance_diagnostics.json").open("w", encoding="utf-8") as stream:
        json.dump(diagnostics, stream, ensure_ascii=False, indent=2)
    splits = list(zip(result.train_indices, result.test_indices))
    return splits, plan, {
        "source": "generated_from_spatial_inputs",
        "sample_coordinates": str(sample_path),
        "prediction_grid": str(prediction_path),
        "method": "Prediction-domain-oriented NNDM spatial validation",
        **diagnostics,
    }
