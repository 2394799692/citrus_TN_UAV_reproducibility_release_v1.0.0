# -*- coding: utf-8 -*-
"""Candidate-feature screening and model-driven final feature selection.

Workflow
--------
1. Build multi-ROI wide tables for Raw and CleanV.
2. Remove metadata, vegetation-oriented predictor indices, low-information
   variables, and nearly duplicate variables.
3. Select one representative ROI scale within each feature family using the
   absolute Spearman correlation with the target under CleanV.
4. Construct a balanced candidate pool across feature categories and ROI scales.
5. Use fixed-parameter GBDT, auxiliary five-fold beam search, conventional
   LOOCV reassessment, and local deletion/addition/replacement refinement.
6. Export the selected feature list and LOOCV-based Raw--CleanV, ROI-scale,
   and feature-category ablation comparisons.

The script contains no project-specific paths or sample-ID rules.
"""
from __future__ import annotations

import argparse
import itertools
import json
import math
import re
import warnings
from pathlib import Path
from typing import Dict, Iterable, List, Mapping, Sequence, Tuple

import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from sklearn.base import clone
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import KFold, LeaveOneOut
from sklearn.pipeline import Pipeline


warnings.filterwarnings("ignore")

VEGETATION_INDEX_TOKENS = {
    "NDVI", "GNDVI", "NDRE", "SAVI", "OSAVI", "MSAVI", "MSAVI2", "EVI", "EVI2",
    "RVI", "DVI", "RDVI", "TNDVI", "WDRVI", "TVI", "MTVI", "MCARI", "TCARI",
    "CI_GREEN", "CIGREEN", "CI_RED_EDGE", "CI_RE", "CIRE", "CIREDGE", "RECI",
    "NIR_RED_RATIO", "NIR_RE_RATIO", "NIR_GREEN_RATIO", "RGB_EXG", "RGB_EXGR",
    "RGB_NGRDI", "RGB_VARI", "RGB_RGBVI",
}
STAT_SUFFIXES = ("median", "mean", "std", "cv", "min", "max", "p10", "p25", "p50", "p75", "p90")


def load_config(path: str | Path) -> Tuple[dict, Path]:
    path = Path(path).resolve()
    with path.open("r", encoding="utf-8") as stream:
        config = json.load(stream)
    return config, path.parent


def resolve_path(root: Path, value: str | Path) -> Path:
    path = Path(value)
    return path if path.is_absolute() else root / path


def read_csv(path: Path) -> pd.DataFrame:
    for encoding in ("utf-8-sig", "utf-8", "gbk"):
        try:
            return pd.read_csv(path, encoding=encoding)
        except Exception:
            continue
    return pd.read_csv(path)


def rmse(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    return float(np.sqrt(mean_squared_error(y_true, y_pred)))


def rpd(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    error = rmse(y_true, y_pred)
    return float(np.std(y_true, ddof=1) / error) if error > 0 else np.nan


def transform_target(y: np.ndarray, name: str) -> np.ndarray:
    y = np.asarray(y, dtype=float)
    return np.log1p(np.clip(y, 0, None)) if name == "log1p" else y.copy()


def inverse_target(y: np.ndarray, name: str) -> np.ndarray:
    y = np.asarray(y, dtype=float)
    return np.expm1(y) if name == "log1p" else y.copy()


def normalize_token(text: str) -> str:
    token = re.sub(r"[^A-Z0-9]+", "_", str(text).upper())
    return re.sub(r"_+", "_", token).strip("_")


def split_roi_prefix(feature: str) -> Tuple[float, str]:
    match = re.match(r"^R(\d+(?:\.\d+)?)m__(.+)$", str(feature))
    if not match:
        return np.nan, str(feature)
    return float(match.group(1)), match.group(2)


def split_core_stat(base_name: str) -> Tuple[str, str]:
    for statistic in sorted(STAT_SUFFIXES, key=len, reverse=True):
        suffix = "_" + statistic
        if base_name.lower().endswith(suffix.lower()):
            return base_name[:-len(suffix)], statistic
    return base_name, ""


def parse_feature(feature: str) -> Dict[str, object]:
    roi, base = split_roi_prefix(feature)
    core, statistic = split_core_stat(base)
    return {
        "Feature": str(feature),
        "ROI_m": roi,
        "Base_name": base,
        "Core_feature": core,
        "Statistic": statistic,
        "Feature_family": f"{core}__{statistic}" if statistic else core,
    }


def is_vegetation_predictor(feature: str) -> bool:
    core = normalize_token(parse_feature(feature)["Core_feature"])
    for token in VEGETATION_INDEX_TOKENS:
        normalized = normalize_token(token)
        if core == normalized or re.search(rf"(^|_){re.escape(normalized)}($|_)", core):
            return True
    return False


def classify_feature(feature: str) -> str:
    core = normalize_token(parse_feature(feature)["Core_feature"])
    if any(token in core for token in ("TEX", "GLCM", "ENTROPY", "ENERGY", "ASM", "CONTRAST", "HOMOGENEITY", "CORRELATION")):
        return "Texture"
    if "VISIBLE_BRIGHTNESS" in core:
        return "Visible brightness"
    if any(token in core for token in ("RGB_R_RAW", "RGB_G_RAW", "RGB_B_RAW")):
        return "RGB raw channel"
    if "RGB_GRAY" in core:
        return "RGB brightness"
    if any(token in core for token in ("RGB_EXB", "RGB_EXR", "CHROMA", "REDNESS", "COLOUR", "COLOR")):
        return "Colour heterogeneity"
    if core.startswith("BAND_") or any(token in core for token in ("NIR", "REDEDGE", "RED_EDGE", "GREEN_RED_RATIO", "RED_GREEN_RATIO", "BRIGHTNESS")):
        return "Multispectral"
    return "Other"


def build_wide_table(
    long_table: pd.DataFrame,
    mask_name: str,
    target: str,
    metadata_columns: Sequence[str],
) -> pd.DataFrame:
    subset = long_table.loc[long_table["Mask_Version"].astype(str) == mask_name].copy()
    if subset.empty:
        raise ValueError(f"No rows were found for mask '{mask_name}'.")

    excluded = set(metadata_columns) | {"Sample_ID", "ROI_Size_m", "Mask_Version", target}
    feature_columns = [
        column for column in subset.columns
        if column not in excluded and pd.api.types.is_numeric_dtype(subset[column])
    ]
    sample_target = subset[["Sample_ID", target]].drop_duplicates("Sample_ID").set_index("Sample_ID")
    pieces = [sample_target]
    for roi_size, roi_table in subset.groupby("ROI_Size_m"):
        roi_value = float(roi_size)
        renamed = roi_table.set_index("Sample_ID")[feature_columns].copy()
        renamed.columns = [f"R{roi_value:.2f}m__{column}" for column in renamed.columns]
        pieces.append(renamed)
    wide = pd.concat(pieces, axis=1).reset_index()
    wide[target] = pd.to_numeric(wide[target], errors="coerce")
    return wide.sort_values("Sample_ID").reset_index(drop=True)


def safe_spearman(x: Sequence[float], y: Sequence[float], minimum_n: int) -> Tuple[float, float, int]:
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    valid = np.isfinite(x) & np.isfinite(y)
    count = int(valid.sum())
    if count < minimum_n or np.nanstd(x[valid]) < 1e-12 or np.nanstd(y[valid]) < 1e-12:
        return np.nan, np.nan, count
    correlation, p_value = spearmanr(x[valid], y[valid])
    return float(correlation), float(p_value), count


def make_fixed_gbdt(config: Mapping) -> Pipeline:
    parameters = dict(config["feature_selection"]["gbdt_params"])
    parameters["random_state"] = int(config["feature_selection"].get("random_state", 2026))
    return Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("model", GradientBoostingRegressor(**parameters)),
    ])


def cross_validated_metrics(
    table: pd.DataFrame,
    features: Sequence[str],
    target: str,
    target_transform: str,
    splitter,
    model: Pipeline,
) -> Dict[str, object]:
    X = table[list(features)].apply(pd.to_numeric, errors="coerce").to_numpy(dtype=float)
    y = pd.to_numeric(table[target], errors="coerce").to_numpy(dtype=float)
    valid_target = np.isfinite(y)
    X = X[valid_target]
    y = y[valid_target]
    transformed = transform_target(y, target_transform)
    predicted_transformed = np.full(len(y), np.nan, dtype=float)

    splits = splitter.split(X) if hasattr(splitter, "split") else splitter
    for train_indices, test_indices in splits:
        fitted = clone(model)
        fitted.fit(X[train_indices], transformed[train_indices])
        predicted_transformed[test_indices] = np.ravel(fitted.predict(X[test_indices]))

    predicted = inverse_target(predicted_transformed, target_transform)
    return {
        "Feature_N": len(features),
        "Features": json.dumps(list(features), ensure_ascii=False),
        "R2": float(r2_score(y, predicted)),
        "RMSE": rmse(y, predicted),
        "MAE": float(mean_absolute_error(y, predicted)),
        "RPD": rpd(y, predicted),
        "Observed": y,
        "Predicted": predicted,
    }


def audit_features(table: pd.DataFrame, target: str, config: Mapping) -> Tuple[pd.DataFrame, List[str]]:
    selection = config["feature_selection"]
    sample_n = int(table[target].notna().sum())
    minimum_n = int(selection.get("min_valid_n", max(5, math.ceil(sample_n * 0.90))))
    minimum_ratio = float(selection.get("min_valid_ratio", 0.90))
    minimum_unique = int(selection.get("min_unique_values", 5))
    minimum_std = float(selection.get("min_std", 1e-12))

    rows = []
    kept: List[str] = []
    for feature in [column for column in table.columns if column not in {"Sample_ID", target}]:
        series = pd.to_numeric(table[feature], errors="coerce")
        valid_n = int(series.notna().sum())
        valid_ratio = valid_n / max(sample_n, 1)
        unique_n = int(series.nunique(dropna=True))
        standard_deviation = float(series.std(skipna=True)) if valid_n > 1 else np.nan
        reasons = []
        if is_vegetation_predictor(feature):
            reasons.append("Vegetation-oriented predictor")
        if valid_n < minimum_n:
            reasons.append("Insufficient valid values")
        if valid_ratio < minimum_ratio:
            reasons.append("Low valid-data ratio")
        if unique_n < minimum_unique:
            reasons.append("Too few unique values")
        if not np.isfinite(standard_deviation) or abs(standard_deviation) < minimum_std:
            reasons.append("Near-constant variable")
        decision = "Keep" if not reasons else "Remove"
        if decision == "Keep":
            kept.append(feature)
        rows.append({
            **parse_feature(feature),
            "Feature_category": classify_feature(feature),
            "Valid_N": valid_n,
            "Valid_ratio": valid_ratio,
            "Unique_N": unique_n,
            "Std": standard_deviation,
            "Decision": decision,
            "Reason": "; ".join(reasons),
        })
    return pd.DataFrame(rows), kept


def select_family_representatives(
    table: pd.DataFrame,
    features: Sequence[str],
    target: str,
    minimum_n: int,
) -> Tuple[pd.DataFrame, List[str]]:
    y = pd.to_numeric(table[target], errors="coerce").to_numpy(dtype=float)
    rows = []
    for feature in features:
        correlation, p_value, valid_n = safe_spearman(table[feature], y, minimum_n)
        rows.append({
            **parse_feature(feature),
            "Feature_category": classify_feature(feature),
            "Spearman_rho": correlation,
            "Abs_Spearman": abs(correlation) if np.isfinite(correlation) else np.nan,
            "P_value": p_value,
            "Valid_N": valid_n,
        })
    correlations = pd.DataFrame(rows)
    representatives = (
        correlations.sort_values(["Feature_family", "Abs_Spearman", "ROI_m"], ascending=[True, False, True])
        .groupby("Feature_family", as_index=False)
        .first()
    )
    return correlations, representatives["Feature"].tolist()


def remove_near_duplicates(
    table: pd.DataFrame,
    representatives: Sequence[str],
    score_lookup: Mapping[str, float],
    threshold: float,
) -> Tuple[List[str], pd.DataFrame]:
    ordered = sorted(representatives, key=lambda feature: (-float(score_lookup.get(feature, -np.inf)), feature))
    retained: List[str] = []
    rows = []
    for candidate in ordered:
        removed_by = None
        removed_correlation = np.nan
        for existing in retained:
            pair = table[[candidate, existing]].apply(pd.to_numeric, errors="coerce").dropna()
            if len(pair) < 5:
                continue
            correlation = pair[candidate].corr(pair[existing], method="spearman")
            if np.isfinite(correlation) and abs(correlation) >= threshold:
                removed_by = existing
                removed_correlation = float(correlation)
                break
        keep = removed_by is None
        if keep:
            retained.append(candidate)
        rows.append({
            "Feature": candidate,
            "Decision": "Keep" if keep else "Remove",
            "Matched_feature": removed_by,
            "Spearman_rho": removed_correlation,
            "Threshold": threshold,
        })
    return retained, pd.DataFrame(rows)


def build_candidate_pool(
    representative_table: pd.DataFrame,
    retained_features: Sequence[str],
    config: Mapping,
) -> pd.DataFrame:
    selection = config["feature_selection"]
    maximum = int(selection.get("max_candidate_pool", 60))
    global_top = int(selection.get("global_top_n", 30))
    category_top = int(selection.get("category_top_n", 10))
    roi_top = int(selection.get("roi_top_n", 8))

    table = representative_table[representative_table["Feature"].isin(retained_features)].copy()
    table = table.sort_values("Abs_Spearman", ascending=False)
    chosen: List[str] = table.head(global_top)["Feature"].tolist()
    for _, group in table.groupby("Feature_category"):
        chosen.extend(group.head(category_top)["Feature"].tolist())
    for _, group in table.groupby("ROI_m"):
        chosen.extend(group.head(roi_top)["Feature"].tolist())
    ordered = []
    for feature in chosen:
        if feature not in ordered:
            ordered.append(feature)
    ordered = ordered[:maximum]
    pool = table.set_index("Feature").loc[ordered].reset_index()
    pool["Pool_order"] = np.arange(1, len(pool) + 1)
    return pool.sort_values("Pool_order")


def set_key(features: Iterable[str]) -> Tuple[str, ...]:
    return tuple(sorted(set(str(value) for value in features)))


def beam_search(
    table: pd.DataFrame,
    candidate_features: Sequence[str],
    target: str,
    config: Mapping,
    fixed_model: Pipeline,
) -> pd.DataFrame:
    selection = config["feature_selection"]
    splits = int(selection.get("screen_cv_splits", 5))
    beam_width = int(selection.get("beam_width", 4))
    maximum_features = int(selection.get("max_forward_features", 7))
    transform = config["modeling"].get("target_transform", "log1p")
    random_state = int(selection.get("random_state", 2026))
    splitter = KFold(n_splits=splits, shuffle=True, random_state=random_state)

    beam: List[Tuple[str, ...]] = [tuple()]
    rows = []
    evaluated: Dict[Tuple[str, ...], Dict[str, object]] = {}
    for size in range(1, maximum_features + 1):
        candidates = set()
        for current in beam:
            for feature in candidate_features:
                if feature not in current:
                    candidates.add(set_key((*current, feature)))
        scored = []
        for feature_set in candidates:
            if feature_set not in evaluated:
                evaluated[feature_set] = cross_validated_metrics(
                    table, feature_set, target, transform, splitter, fixed_model
                )
            metrics = evaluated[feature_set]
            scored.append((feature_set, metrics))
            rows.append({
                "Stage": "Fivefold beam search",
                "Feature_N": size,
                "Features": json.dumps(list(feature_set), ensure_ascii=False),
                "R2": metrics["R2"],
                "RMSE": metrics["RMSE"],
                "MAE": metrics["MAE"],
                "RPD": metrics["RPD"],
            })
        scored.sort(key=lambda item: (-item[1]["R2"], item[1]["RMSE"], item[1]["MAE"]))
        beam = [item[0] for item in scored[:beam_width]]
    return pd.DataFrame(rows)


def loocv_reassessment(
    table: pd.DataFrame,
    beam_results: pd.DataFrame,
    target: str,
    config: Mapping,
    fixed_model: Pipeline,
    validation_splits,
) -> pd.DataFrame:
    selection = config["feature_selection"]
    top_per_size = int(selection.get("loocv_top_per_size", 4))
    transform = config["modeling"].get("target_transform", "log1p")
    rows = []
    for _, group in beam_results.groupby("Feature_N"):
        selected = group.sort_values(["R2", "RMSE", "MAE"], ascending=[False, True, True]).head(top_per_size)
        for _, row in selected.iterrows():
            features = json.loads(row["Features"])
            metrics = cross_validated_metrics(
                table, features, target, transform, validation_splits, fixed_model
            )
            rows.append({
                "Stage": "LOOCV reassessment",
                "Feature_N": len(features),
                "Features": json.dumps(features, ensure_ascii=False),
                "R2": metrics["R2"],
                "RMSE": metrics["RMSE"],
                "MAE": metrics["MAE"],
                "RPD": metrics["RPD"],
            })
    return pd.DataFrame(rows).drop_duplicates("Features")


def local_refinement(
    table: pd.DataFrame,
    loocv_results: pd.DataFrame,
    candidate_features: Sequence[str],
    target: str,
    config: Mapping,
    fixed_model: Pipeline,
    validation_splits,
) -> pd.DataFrame:
    transform = config["modeling"].get("target_transform", "log1p")
    rounds = int(config["feature_selection"].get("local_refinement_rounds", 1))
    unused_limit = int(config["feature_selection"].get("local_unused_n", 25))
    minimum_features = int(config["feature_selection"].get("minimum_final_features", 3))

    best_row = loocv_results.sort_values(["R2", "RMSE", "MAE"], ascending=[False, True, True]).iloc[0]
    current = tuple(json.loads(best_row["Features"]))
    cache: Dict[Tuple[str, ...], Dict[str, object]] = {}
    output_rows = []

    def evaluate(features: Sequence[str], operation: str) -> Dict[str, object]:
        key = set_key(features)
        if key not in cache:
            cache[key] = cross_validated_metrics(
                table, key, target, transform, validation_splits, fixed_model
            )
        metrics = cache[key]
        row = {
            "Operation": operation,
            "Feature_N": len(key),
            "Features": json.dumps(list(key), ensure_ascii=False),
            "R2": metrics["R2"],
            "RMSE": metrics["RMSE"],
            "MAE": metrics["MAE"],
            "RPD": metrics["RPD"],
        }
        output_rows.append(row)
        return row

    current_row = evaluate(current, "Initial LOOCV finalist")
    for _ in range(rounds):
        candidates = [current_row]
        if len(current) > minimum_features:
            for feature in current:
                candidates.append(evaluate([value for value in current if value != feature], f"Delete {feature}"))
        unused = [feature for feature in candidate_features if feature not in current][:unused_limit]
        for feature in unused:
            candidates.append(evaluate((*current, feature), f"Add {feature}"))
        for old_feature in current:
            reduced = [feature for feature in current if feature != old_feature]
            for new_feature in unused:
                candidates.append(evaluate((*reduced, new_feature), f"Replace {old_feature} with {new_feature}"))
        best = sorted(candidates, key=lambda row: (-row["R2"], row["RMSE"], row["MAE"], row["Feature_N"]))[0]
        new_current = tuple(json.loads(best["Features"]))
        if set_key(new_current) == set_key(current):
            break
        current = new_current
        current_row = best
    return pd.DataFrame(output_rows).drop_duplicates("Features")


def select_final_set(all_results: pd.DataFrame, tolerance: float) -> pd.Series:
    best_rmse = float(all_results["RMSE"].min())
    eligible = all_results[all_results["RMSE"] <= best_rmse * (1.0 + tolerance)].copy()
    return eligible.sort_values(["Feature_N", "RMSE", "R2"], ascending=[True, True, False]).iloc[0]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config_example.json")
    arguments = parser.parse_args()
    config, root = load_config(arguments.config)

    output_root = resolve_path(root, config["paths"]["output_dir"])
    roi_feature_path = output_root / "roi_features" / "bare_soil_multiscale_features.csv"
    output_dir = output_root / "feature_selection"
    output_dir.mkdir(parents=True, exist_ok=True)

    long_table = read_csv(roi_feature_path)
    target = config["analysis"]["main_target"]
    if target not in long_table.columns:
        raise ValueError(f"Target column is absent from the feature table: {target}")

    metadata_columns = config["feature_selection"].get(
        "metadata_columns",
        ["Raw_Valid_Pixels", "Final_Valid_Pixels", "Retain_Ratio"],
    )
    cleanv_wide = build_wide_table(long_table, "CleanV", target, metadata_columns)
    raw_wide = build_wide_table(long_table, "Raw", target, metadata_columns)
    cleanv_wide.to_csv(output_dir / "wide_modeling_table.csv", index=False, encoding="utf-8-sig")
    raw_wide.to_csv(output_dir / "wide_raw_table.csv", index=False, encoding="utf-8-sig")

    validation_data = cleanv_wide.loc[cleanv_wide[target].notna()].copy().reset_index(drop=True)
    # Formal feature-subset reassessment, local refinement, and TN ablations use
    # conventional leave-one-out cross-validation (LOOCV). Prediction-domain-
    # oriented NNDM is intentionally introduced only after the feature
    # configuration has been fixed, in script 03.
    validation_splits = list(LeaveOneOut().split(np.arange(len(validation_data))))
    validation_info = {
        "method": "conventional leave-one-out cross-validation (LOOCV)",
        "sample_n": int(len(validation_data)),
        "role": "final feature-subset determination and TN ablation analyses",
    }

    audit, eligible = audit_features(cleanv_wide, target, config)
    audit.to_csv(output_dir / "feature_audit.csv", index=False, encoding="utf-8-sig")

    minimum_n = int(config["feature_selection"].get("min_valid_n", max(5, math.ceil(len(cleanv_wide) * 0.90))))
    correlations, representatives = select_family_representatives(cleanv_wide, eligible, target, minimum_n)
    correlations.to_csv(output_dir / "cleanv_feature_correlations.csv", index=False, encoding="utf-8-sig")

    representative_table = (
        correlations.sort_values(["Feature_family", "Abs_Spearman", "ROI_m"], ascending=[True, False, True])
        .groupby("Feature_family", as_index=False)
        .first()
    )
    representative_table.to_csv(output_dir / "family_representatives.csv", index=False, encoding="utf-8-sig")
    score_lookup = dict(zip(correlations["Feature"], correlations["Abs_Spearman"]))
    retained, duplicate_log = remove_near_duplicates(
        cleanv_wide,
        representatives,
        score_lookup,
        float(config["feature_selection"].get("near_duplicate_threshold", 0.995)),
    )
    duplicate_log.to_csv(output_dir / "near_duplicate_log.csv", index=False, encoding="utf-8-sig")

    candidate_pool = build_candidate_pool(representative_table, retained, config)
    candidate_pool.to_csv(output_dir / "candidate_pool.csv", index=False, encoding="utf-8-sig")
    candidate_features = candidate_pool["Feature"].tolist()
    if not candidate_features:
        raise RuntimeError("The candidate pool is empty.")

    fixed_model = make_fixed_gbdt(config)
    beam = beam_search(cleanv_wide, candidate_features, target, config, fixed_model)
    beam.to_csv(output_dir / "beam_search_fivefold.csv", index=False, encoding="utf-8-sig")
    reassessed = loocv_reassessment(cleanv_wide, beam, target, config, fixed_model, validation_splits)
    reassessed.to_csv(output_dir / "loocv_reassessment.csv", index=False, encoding="utf-8-sig")
    refined = local_refinement(cleanv_wide, reassessed, candidate_features, target, config, fixed_model, validation_splits)
    refined.to_csv(output_dir / "local_refinement.csv", index=False, encoding="utf-8-sig")

    all_loocv = pd.concat([reassessed, refined.rename(columns={"Operation": "Stage"})], ignore_index=True)
    all_loocv = all_loocv.drop_duplicates("Features")
    all_loocv.to_csv(output_dir / "all_loocv_feature_sets.csv", index=False, encoding="utf-8-sig")
    final_row = select_final_set(
        all_loocv,
        float(config["feature_selection"].get("parsimony_rmse_tolerance", 0.0025)),
    )
    final_features = json.loads(final_row["Features"])

    final_table = correlations[correlations["Feature"].isin(final_features)].copy()
    final_table["Final_order"] = final_table["Feature"].map({feature: index + 1 for index, feature in enumerate(final_features)})
    final_table = final_table.sort_values("Final_order")
    final_table.to_csv(output_dir / "final_selected_features.csv", index=False, encoding="utf-8-sig")

    transform = config["modeling"].get("target_transform", "log1p")

    # Fixed-feature Raw--CleanV ablation under conventional LOOCV.
    ablation_rows = []
    for label, table in (("Raw", raw_wide), ("CleanV", cleanv_wide)):
        metrics = cross_validated_metrics(
            table, final_features, target, transform, validation_splits, fixed_model
        )
        ablation_rows.append({
            "Pixel_scheme": label,
            "Feature_N": len(final_features),
            "R2": metrics["R2"],
            "RMSE": metrics["RMSE"],
            "MAE": metrics["MAE"],
            "RPD": metrics["RPD"],
            "Validation": "conventional LOOCV",
        })
    pd.DataFrame(ablation_rows).to_csv(
        output_dir / "fixed_feature_Raw_CleanV_LOOCV_comparison.csv",
        index=False,
        encoding="utf-8-sig",
    )

    # Single-scale ROI ablation: replace every final feature with the same
    # feature family/statistic at a common ROI scale.
    roi_rows = []
    reference_metrics = cross_validated_metrics(
        cleanv_wide, final_features, target, transform, validation_splits, fixed_model
    )
    roi_rows.append({
        "Configuration": "Multi-scale reference",
        "ROI_m": "0.50+0.80",
        "Feature_N": len(final_features),
        "Features": json.dumps(final_features, ensure_ascii=False),
        "R2": reference_metrics["R2"],
        "RMSE": reference_metrics["RMSE"],
        "MAE": reference_metrics["MAE"],
        "RPD": reference_metrics["RPD"],
        "Validation": "conventional LOOCV",
    })
    for roi in (0.30, 0.50, 0.80):
        replacements = []
        missing = []
        for feature in final_features:
            _, base = split_roi_prefix(feature)
            candidate = f"R{roi:.2f}m__{base}"
            if candidate not in cleanv_wide.columns:
                missing.append(candidate)
            replacements.append(candidate)
        if missing:
            roi_rows.append({
                "Configuration": f"Single-scale {roi:.2f} m",
                "ROI_m": roi,
                "Feature_N": len(replacements),
                "Features": json.dumps(replacements, ensure_ascii=False),
                "R2": np.nan, "RMSE": np.nan, "MAE": np.nan, "RPD": np.nan,
                "Validation": "conventional LOOCV",
                "Note": "Missing corresponding features: " + "; ".join(missing),
            })
            continue
        metrics = cross_validated_metrics(
            cleanv_wide, replacements, target, transform, validation_splits, fixed_model
        )
        roi_rows.append({
            "Configuration": f"Single-scale {roi:.2f} m",
            "ROI_m": roi,
            "Feature_N": len(replacements),
            "Features": json.dumps(replacements, ensure_ascii=False),
            "R2": metrics["R2"], "RMSE": metrics["RMSE"],
            "MAE": metrics["MAE"], "RPD": metrics["RPD"],
            "Validation": "conventional LOOCV",
        })
    pd.DataFrame(roi_rows).to_csv(
        output_dir / "roi_scale_ablation_LOOCV.csv", index=False, encoding="utf-8-sig"
    )

    # Feature-category ablation under the same fixed GBDT and LOOCV procedure.
    category_definitions = {
        "Remove RGB brightness": [f for f in final_features if classify_feature(f) == "RGB brightness"],
        "Remove visible brightness": [f for f in final_features if classify_feature(f) == "Visible brightness"],
        "Remove colour heterogeneity": [f for f in final_features if classify_feature(f) == "Colour heterogeneity"],
    }
    category_rows = [{
        "Configuration": "Full five-feature reference",
        "Removed_features": "",
        "Feature_N": len(final_features),
        "R2": reference_metrics["R2"], "RMSE": reference_metrics["RMSE"],
        "MAE": reference_metrics["MAE"], "RPD": reference_metrics["RPD"],
        "Validation": "conventional LOOCV",
    }]
    for label, removed in category_definitions.items():
        retained_features = [f for f in final_features if f not in set(removed)]
        if not removed or not retained_features:
            continue
        metrics = cross_validated_metrics(
            cleanv_wide, retained_features, target, transform, validation_splits, fixed_model
        )
        category_rows.append({
            "Configuration": label,
            "Removed_features": ";".join(removed),
            "Feature_N": len(retained_features),
            "R2": metrics["R2"], "RMSE": metrics["RMSE"],
            "MAE": metrics["MAE"], "RPD": metrics["RPD"],
            "Validation": "conventional LOOCV",
        })
    pd.DataFrame(category_rows).to_csv(
        output_dir / "feature_category_ablation_LOOCV.csv", index=False, encoding="utf-8-sig"
    )

    summary = {
        "Initial_numeric_feature_count": int(len(audit)),
        "Quality_retained_feature_count": int(len(eligible)),
        "Cross_scale_family_count": int(len(representative_table)),
        "Near_duplicate_retained_count": int(len(retained)),
        "Candidate_pool_count": int(len(candidate_features)),
        "Final_feature_count": int(len(final_features)),
        "Final_features": final_features,
        "Validation": validation_info,
        "Fixed_GBDT_LOOCV_R2": float(final_row["R2"]),
        "Fixed_GBDT_LOOCV_RMSE": float(final_row["RMSE"]),
        "Fixed_GBDT_LOOCV_MAE": float(final_row["MAE"]),
        "Fixed_GBDT_LOOCV_RPD": float(final_row["RPD"]),
        "Next_stage": "prediction-domain-oriented NNDM model comparison after the feature configuration is fixed",
    }
    with (output_dir / "feature_selection_summary.json").open("w", encoding="utf-8") as stream:
        json.dump(summary, stream, ensure_ascii=False, indent=2)

    print(f"Saved selected features: {output_dir / 'final_selected_features.csv'}")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
