# -*- coding: utf-8 -*-
"""Reproduce the manuscript six-model TN comparison with fixed parameters.

The final five TN features, archived NNDM fold plan, target transformation, and
model hyperparameters are fixed. Repeated ten-fold cross-validation is optional
and serves only as a sensitivity analysis of random sample partitioning.
"""
from __future__ import annotations

import argparse
import json
from collections import OrderedDict
from pathlib import Path
from typing import Mapping

import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.cross_decomposition import PLSRegression
from sklearn.ensemble import ExtraTreesRegressor, GradientBoostingRegressor, RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import KFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVR

from nndm_validation import load_fold_plan, read_table


MODEL_SPECS = OrderedDict({
    "GBDT": {
        "parameters": {
            "n_estimators": 900,
            "learning_rate": 0.03,
            "max_depth": 2,
            "min_samples_leaf": 1,
            "subsample": 1.0,
        },
        "paper_repeated_10fold_r2": "0.695 ± 0.038",
    },
    "XGBoost": {
        "parameters": {
            "n_estimators": 800,
            "learning_rate": 0.05,
            "max_depth": 2,
            "min_child_weight": 2,
            "subsample": 1.0,
            "colsample_bytree": 0.8,
            "reg_lambda": 1.0,
        },
        "paper_repeated_10fold_r2": "0.621 ± 0.040",
    },
    "RF": {
        "parameters": {
            "n_estimators": 500,
            "max_depth": None,
            "min_samples_leaf": 1,
            "max_features": 0.8,
        },
        "paper_repeated_10fold_r2": "0.536 ± 0.028",
    },
    "ExtraTrees": {
        "parameters": {
            "n_estimators": 300,
            "max_depth": None,
            "min_samples_leaf": 1,
            "max_features": 0.8,
        },
        "paper_repeated_10fold_r2": "0.527 ± 0.028",
    },
    "SVR": {
        "parameters": {"C": 50.0, "gamma": 0.01, "epsilon": 0.08},
        "paper_repeated_10fold_r2": "0.346 ± 0.068",
    },
    "PLSR": {
        "parameters": {"n_components": 2},
        "paper_repeated_10fold_r2": "0.116 ± 0.038",
    },
})


def build_model(name: str, parameters: Mapping, random_state: int) -> Pipeline:
    parameters = dict(parameters)
    if name == "PLSR":
        estimator = PLSRegression(**parameters)
        return Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
            ("model", estimator),
        ])
    if name == "SVR":
        estimator = SVR(kernel="rbf", **parameters)
        return Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
            ("model", estimator),
        ])
    if name == "GBDT":
        parameters["random_state"] = random_state
        estimator = GradientBoostingRegressor(**parameters)
    elif name == "RF":
        parameters["random_state"] = random_state
        estimator = RandomForestRegressor(n_jobs=1, **parameters)
    elif name == "ExtraTrees":
        parameters["random_state"] = random_state
        estimator = ExtraTreesRegressor(n_jobs=1, **parameters)
    elif name == "XGBoost":
        try:
            from xgboost import XGBRegressor
        except Exception as exc:
            raise ImportError("xgboost is required for the XGBoost comparison.") from exc
        parameters["random_state"] = random_state
        estimator = XGBRegressor(
            objective="reg:squarederror", n_jobs=1, verbosity=0, **parameters
        )
    else:
        raise ValueError(name)
    return Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("model", estimator),
    ])


def predict_splits(model, X, y, splits):
    transformed = np.log1p(np.clip(y, 0, None))
    predicted = np.full(len(y), np.nan, dtype=float)
    for train_idx, test_idx in splits:
        fitted = clone(model)
        fitted.fit(X[train_idx], transformed[train_idx])
        predicted[test_idx] = np.ravel(fitted.predict(X[test_idx]))
    return np.expm1(predicted)


def metric_row(y, pred):
    error = pred - y
    rmse = float(np.sqrt(mean_squared_error(y, pred)))
    return {
        "NNDM_R2": float(r2_score(y, pred)),
        "RMSE_g_kg": rmse / 1000.0,
        "MAE_g_kg": float(mean_absolute_error(y, pred)) / 1000.0,
        "RPD": float(np.std(y, ddof=1) / rmse),
    }


def repeated_tenfold(model, X, y, repeats, random_state):
    values = []
    for repeat in range(repeats):
        splitter = KFold(n_splits=10, shuffle=True, random_state=random_state + repeat)
        pred = predict_splits(model, X, y, list(splitter.split(X)))
        values.append(float(r2_score(y, pred)))
    return float(np.mean(values)), float(np.std(values, ddof=1)), values


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--data",
        default="data/reproducibility_current/final_5_features_TN_modeling_data_current.csv",
    )
    parser.add_argument(
        "--fold-plan", default="data/reproducibility_current/nndm_folds_current.csv"
    )
    parser.add_argument("--output", default="outputs/six_model_fixed_nndm")
    parser.add_argument("--random-state", type=int, default=2026)
    parser.add_argument(
        "--models",
        default=",".join(MODEL_SPECS.keys()),
        help="Comma-separated subset of models; default runs all six.",
    )
    parser.add_argument("--run-repeated-tenfold", action="store_true")
    parser.add_argument("--repeats", type=int, default=100)
    args = parser.parse_args()

    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    data = read_table(args.data)
    sample_ids = data["Sample_ID"].astype(str).to_numpy()
    features = [c for c in data.columns if c not in {"Sample_ID", "TN_mg_kg"}]
    X = data[features].apply(pd.to_numeric, errors="coerce").to_numpy(float)
    y = pd.to_numeric(data["TN_mg_kg"], errors="coerce").to_numpy(float)
    splits, plan = load_fold_plan(args.fold_plan, sample_ids)

    summary_rows = []
    prediction_rows = []
    repeat_rows = []
    requested = [value.strip() for value in args.models.split(",") if value.strip()]
    unknown = [value for value in requested if value not in MODEL_SPECS]
    if unknown:
        raise ValueError(f"Unknown model names: {unknown}")

    for name in requested:
        spec = MODEL_SPECS[name]
        model = build_model(name, spec["parameters"], args.random_state)
        prediction = predict_splits(model, X, y, splits)
        row = {
            "Model": name,
            **metric_row(y, prediction),
            "Repeated_10fold_R2": spec["paper_repeated_10fold_r2"],
            "Fixed_parameters": json.dumps(spec["parameters"], sort_keys=True),
        }
        if args.run_repeated_tenfold:
            mean_r2, sd_r2, values = repeated_tenfold(
                model, X, y, args.repeats, args.random_state
            )
            row["Recomputed_repeated_10fold_R2_mean"] = mean_r2
            row["Recomputed_repeated_10fold_R2_sd"] = sd_r2
            repeat_rows.extend(
                {"Model": name, "Repeat": i + 1, "R2": value}
                for i, value in enumerate(values)
            )
        summary_rows.append(row)
        prediction_rows.extend(
            {
                "Model": name,
                "Sample_ID": sample_id,
                "Measured_TN_g_kg": observed / 1000.0,
                "Predicted_TN_g_kg": predicted / 1000.0,
                "Residual_g_kg": (predicted - observed) / 1000.0,
            }
            for sample_id, observed, predicted in zip(sample_ids, y, prediction)
        )

    summary = pd.DataFrame(summary_rows).sort_values("NNDM_R2", ascending=False)
    summary.to_csv(output / "six_model_fixed_NNDM_summary.csv", index=False, encoding="utf-8-sig")
    pd.DataFrame(prediction_rows).to_csv(
        output / "six_model_fixed_NNDM_predictions.csv", index=False, encoding="utf-8-sig"
    )
    plan.to_csv(output / "NNDM_folds_used.csv", index=False, encoding="utf-8-sig")
    if repeat_rows:
        pd.DataFrame(repeat_rows).to_csv(
            output / "repeated_tenfold_R2.csv", index=False, encoding="utf-8-sig"
        )
    print(summary.to_string(index=False))
    print(f"Saved outputs to: {output}")


if __name__ == "__main__":
    main()
