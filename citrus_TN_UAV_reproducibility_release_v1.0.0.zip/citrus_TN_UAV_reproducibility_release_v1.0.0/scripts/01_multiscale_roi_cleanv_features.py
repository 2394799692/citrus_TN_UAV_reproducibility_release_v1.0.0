# -*- coding: utf-8 -*-
"""Multi-scale ROI construction, CleanV purification, and feature extraction.

The script applies 0.30, 0.50, and 0.80 m square ROIs centred on supplied
sample coordinates. For each ROI it exports both Raw and CleanV feature rows.
The same formulas are imported from ``workflow_core.py`` by the mapping module.

No project-specific sample identifiers, coordinates, or paths are embedded.
"""
from __future__ import annotations

import argparse
import json
import warnings
from pathlib import Path
from typing import Dict, Mapping, Tuple

import geopandas as gpd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import rasterio
from rasterio.mask import mask as raster_mask
from rasterio.warp import Resampling, reproject, transform_geom
from shapely.geometry import Point, box, mapping

from workflow_core import (
    build_cleanv_mask,
    build_valid_mask,
    compute_multispectral_layers,
    compute_rgb_layers,
    formula_reference_table,
    glcm_features,
    normalize_local,
    summarize_layer,
    validate_mask_versions,
)

warnings.filterwarnings("ignore")


def load_config(path: str | Path) -> Tuple[dict, Path]:
    path = Path(path).resolve()
    with path.open("r", encoding="utf-8") as stream:
        config = json.load(stream)
    return config, path.parent


def resolve_path(root: Path, value: str | Path) -> Path:
    path = Path(value)
    return path if path.is_absolute() else root / path


def read_table(path: Path) -> pd.DataFrame:
    if path.suffix.lower() in {".xlsx", ".xls"}:
        return pd.read_excel(path)
    for encoding in ("utf-8-sig", "utf-8", "gbk"):
        try:
            return pd.read_csv(path, encoding=encoding)
        except Exception:
            continue
    return pd.read_csv(path)


def get_resolution_m(dataset: rasterio.io.DatasetReader) -> float:
    x_resolution = abs(dataset.transform.a)
    y_resolution = abs(dataset.transform.e)
    if dataset.crs is not None and dataset.crs.is_geographic:
        return float((x_resolution + y_resolution) / 2.0 * 111320.0)
    return float((x_resolution + y_resolution) / 2.0)


def metres_to_crs_units(dataset: rasterio.io.DatasetReader, metres: float) -> float:
    if dataset.crs is not None and dataset.crs.is_geographic:
        return float(metres / 111320.0)
    return float(metres)


def square_roi_mask(
    shape: Tuple[int, int],
    centre_column: float,
    centre_row: float,
    size_m: float,
    resolution_m: float,
) -> np.ndarray:
    rows, columns = shape
    half_size_pixels = size_m / max(resolution_m, 1e-12) / 2.0
    column_start = max(0, int(np.floor(centre_column - half_size_pixels)))
    column_stop = min(columns, int(np.ceil(centre_column + half_size_pixels)))
    row_start = max(0, int(np.floor(centre_row - half_size_pixels)))
    row_stop = min(rows, int(np.ceil(centre_row + half_size_pixels)))
    roi = np.zeros(shape, dtype=bool)
    roi[row_start:row_stop, column_start:column_stop] = True
    return roi


def crop_rgb_to_working_grid(
    rgb_source: rasterio.io.DatasetReader,
    local_geometry,
    geometry_crs,
    target_shape: Tuple[int, int],
    target_transform,
    target_crs,
) -> np.ndarray | None:
    geometry = mapping(local_geometry)
    if rgb_source.crs is not None and geometry_crs is not None and rgb_source.crs != geometry_crs:
        geometry = transform_geom(geometry_crs, rgb_source.crs, geometry)
    image, source_transform = raster_mask(
        rgb_source,
        [geometry],
        crop=True,
        nodata=0,
        filled=True,
    )
    if image.shape[0] < 3:
        return None
    destination = np.zeros((3, target_shape[0], target_shape[1]), dtype=np.float32)
    for band_index in range(3):
        reproject(
            source=image[band_index].astype(np.float32),
            destination=destination[band_index],
            src_transform=source_transform,
            src_crs=rgb_source.crs,
            dst_transform=target_transform,
            dst_crs=target_crs,
            resampling=Resampling.bilinear,
            src_nodata=0,
            dst_nodata=0,
        )
    return destination


def save_diagnostic(
    output_path: Path,
    rgb: np.ndarray | None,
    roi: np.ndarray,
    cleanv_roi: np.ndarray,
    removed_roi: np.ndarray,
) -> None:
    if rgb is None:
        return
    display = np.dstack([normalize_local(rgb[index]) for index in range(3)])
    figure, axes = plt.subplots(1, 3, figsize=(10.5, 3.5))
    axes[0].imshow(display)
    axes[0].contour(roi, colors="yellow", linewidths=1.2)
    axes[0].set_title("Multi-scale ROI centre")
    axes[1].imshow(display)
    axes[1].imshow(np.where(roi, 1.0, np.nan), cmap="autumn", alpha=0.18)
    axes[1].set_title("Raw ROI")
    axes[2].imshow(display)
    axes[2].imshow(np.where(cleanv_roi, 1.0, np.nan), cmap="Greens", alpha=0.35)
    axes[2].imshow(np.where(removed_roi, 1.0, np.nan), cmap="magma", alpha=0.35)
    axes[2].set_title("CleanV-retained pixels")
    for axis in axes:
        axis.axis("off")
    figure.tight_layout()
    figure.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close(figure)


def open_rasters(config: Mapping, root: Path) -> Dict[str, rasterio.io.DatasetReader]:
    sources: Dict[str, rasterio.io.DatasetReader] = {}
    for band_name, path_text in config["paths"]["rasters"].items():
        raster_path = resolve_path(root, path_text)
        if raster_path.exists():
            sources[band_name] = rasterio.open(raster_path)
    required = {"Green", "Red", "NIR"}
    if not required.issubset(sources):
        raise FileNotFoundError(
            "Green, Red, and NIR orthomosaics are required. Missing: "
            + ", ".join(sorted(required - set(sources)))
        )
    return sources


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config_example.json")
    arguments = parser.parse_args()

    config, root = load_config(arguments.config)
    mask_versions = validate_mask_versions(config["mask"].get("versions", ["Raw", "CleanV"]))
    roi_sizes = [float(value) for value in config["roi"]["sizes_m"]]
    statistics = tuple(config["feature_extraction"]["stats"])
    texture_sources = tuple(
        config["feature_extraction"].get(
            "texture_sources",
            ["RGB_Gray", "Band_Green", "Band_Red", "Band_RedEdge", "Band_NIR"],
        )
    )

    output_root = resolve_path(root, config["paths"]["output_dir"])
    output_dir = output_root / "roi_features"
    diagnostic_dir = output_dir / "diagnostics"
    output_dir.mkdir(parents=True, exist_ok=True)
    diagnostic_dir.mkdir(parents=True, exist_ok=True)

    point_table = read_table(resolve_path(root, config["paths"]["sample_points"]))
    laboratory_table = read_table(resolve_path(root, config["paths"]["soil_lab"]))
    columns = config["columns"]
    sample_id_column = columns["sample_id"]
    point_table[sample_id_column] = point_table[sample_id_column].astype(str)
    laboratory_table[sample_id_column] = laboratory_table[sample_id_column].astype(str)

    points = gpd.GeoDataFrame(
        point_table.copy(),
        geometry=[
            Point(easting, northing)
            for easting, northing in zip(
                point_table[columns["easting"]],
                point_table[columns["northing"]],
            )
        ],
        crs=config["rtk_crs"],
    )

    sources = open_rasters(config, root)
    working_source = sources["NIR"]
    resolution_m = get_resolution_m(working_source)
    if working_source.crs is not None and points.crs != working_source.crs:
        points = points.to_crs(working_source.crs)

    feature_rows = []
    quality_rows = []

    try:
        for _, point in points.iterrows():
            sample_id = str(point[sample_id_column])
            crop_radius = metres_to_crs_units(working_source, float(config["roi"]["crop_radius_m"]))
            local_geometry = box(
                point.geometry.x - crop_radius,
                point.geometry.y - crop_radius,
                point.geometry.x + crop_radius,
                point.geometry.y + crop_radius,
            )

            raw: Dict[str, np.ndarray] = {}
            local_transform = None
            for band_name in ("Green", "Red", "RedEdge", "NIR"):
                if band_name not in sources:
                    continue
                image, transform = raster_mask(
                    sources[band_name],
                    [mapping(local_geometry)],
                    crop=True,
                    nodata=0,
                    filled=True,
                )
                raw[band_name] = image[0].astype(np.float32)
                if local_transform is None:
                    local_transform = transform

            if local_transform is None:
                raise RuntimeError("Could not determine the local raster transform.")
            shape = raw["NIR"].shape
            rgb = None
            if "RGB" in sources:
                rgb = crop_rgb_to_working_grid(
                    sources["RGB"],
                    local_geometry,
                    working_source.crs,
                    shape,
                    local_transform,
                    working_source.crs,
                )

            multispectral_layers = compute_multispectral_layers(raw)
            rgb_aux, rgb_layers = compute_rgb_layers(rgb)
            all_layers = {**multispectral_layers, **rgb_layers}
            valid = build_valid_mask(raw)
            cleanv, vegetation, marker = build_cleanv_mask(
                multispectral_layers,
                rgb_aux,
                valid,
                config["mask"],
            )

            centre_column, centre_row = ~local_transform * (point.geometry.x, point.geometry.y)

            for roi_size in roi_sizes:
                roi = square_roi_mask(shape, centre_column, centre_row, roi_size, resolution_m)
                raw_pixels = int((roi & valid).sum())
                for mask_name in mask_versions:
                    final_mask = roi & (valid if mask_name == "Raw" else cleanv)
                    final_pixels = int(final_mask.sum())
                    record = {
                        "Sample_ID": sample_id,
                        "ROI_Size_m": roi_size,
                        "Mask_Version": mask_name,
                        "Raw_Valid_Pixels": raw_pixels,
                        "Final_Valid_Pixels": final_pixels,
                        "Retain_Ratio": final_pixels / max(raw_pixels, 1),
                    }
                    for layer_name, layer in all_layers.items():
                        record.update(summarize_layer(layer, final_mask, layer_name, statistics))
                    for texture_source in texture_sources:
                        if texture_source in all_layers:
                            record.update(
                                glcm_features(
                                    all_layers[texture_source],
                                    final_mask,
                                    f"Tex_{texture_source}",
                                    int(config["feature_extraction"].get("glcm_levels", 32)),
                                )
                            )
                    feature_rows.append(record)
                    quality_rows.append({
                        "Sample_ID": sample_id,
                        "ROI_Size_m": roi_size,
                        "Mask_Version": mask_name,
                        "Raw_Valid_Pixels": raw_pixels,
                        "Final_Valid_Pixels": final_pixels,
                        "Retain_Ratio": final_pixels / max(raw_pixels, 1),
                    })

                if (
                    config["feature_extraction"].get("save_diagnostic_png", False)
                    and np.isclose(roi_size, max(roi_sizes))
                ):
                    cleanv_roi = roi & cleanv
                    removed_roi = roi & valid & (~cleanv)
                    save_diagnostic(
                        diagnostic_dir / f"{sample_id}_CleanV_diagnostic.png",
                        rgb,
                        roi,
                        cleanv_roi,
                        removed_roi,
                    )
    finally:
        for source in sources.values():
            source.close()

    features = pd.DataFrame(feature_rows)
    features = features.merge(
        laboratory_table,
        left_on="Sample_ID",
        right_on=sample_id_column,
        how="left",
        suffixes=("", "_lab"),
    )
    if sample_id_column != "Sample_ID" and sample_id_column in features.columns:
        features = features.drop(columns=[sample_id_column])

    feature_path = output_dir / "bare_soil_multiscale_features.csv"
    quality_path = output_dir / "roi_quality_control.csv"
    formula_path = output_dir / "feature_formula_reference.csv"
    features.to_csv(feature_path, index=False, encoding="utf-8-sig")
    pd.DataFrame(quality_rows).to_csv(quality_path, index=False, encoding="utf-8-sig")
    formula_reference_table().to_csv(formula_path, index=False, encoding="utf-8-sig")

    print(f"Saved: {feature_path}")
    print(f"Saved: {quality_path}")
    print(f"Saved: {formula_path}")


if __name__ == "__main__":
    main()
