# -*- coding: utf-8 -*-
"""CleanV-constrained ROI-grid TN prediction and spatial mapping.

The module loads the final saved GBDT pipeline and extracts the same selected
features over regular grid centres. It imports all formulas from
``workflow_core.py`` to prevent differences between model development and map
production.

The output is ROI-grid-scale prediction. It is not pixel-wise inversion.
"""
from __future__ import annotations

import argparse
import json
import math
import warnings
from pathlib import Path
from typing import Dict, Mapping, Sequence, Tuple

import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
import numpy as np
import pandas as pd
import rasterio
from rasterio.transform import Affine
from rasterio.windows import Window, transform as window_transform
from rasterio.warp import Resampling, reproject

from workflow_core import (
    build_cleanv_mask,
    build_valid_mask,
    compute_multispectral_layers,
    compute_rgb_layers,
    parse_feature_name,
    statistic_value,
)

warnings.filterwarnings("ignore")
plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams["mathtext.fontset"] = "stix"
plt.rcParams["axes.unicode_minus"] = False


def load_config(path: str | Path) -> Tuple[dict, Path]:
    path = Path(path).resolve()
    with path.open("r", encoding="utf-8") as stream:
        config = json.load(stream)
    return config, path.parent


def resolve_path(root: Path, value: str | Path) -> Path:
    path = Path(value)
    return path if path.is_absolute() else root / path


def read_csv(path: Path) -> pd.DataFrame:
    for encoding in ("utf-8-sig", "utf-8", "gbk"):
        try:
            return pd.read_csv(path, encoding=encoding)
        except Exception:
            continue
    return pd.read_csv(path)


def inverse_target(values: np.ndarray, name: str) -> np.ndarray:
    values = np.asarray(values, dtype=float)
    return np.expm1(values) if name == "log1p" else values.copy()


def get_resolution_m(dataset: rasterio.io.DatasetReader, fallback: float) -> float:
    x_resolution = abs(dataset.transform.a)
    y_resolution = abs(dataset.transform.e)
    if dataset.crs is not None and dataset.crs.is_projected:
        return float((x_resolution + y_resolution) / 2.0)
    if dataset.crs is not None and dataset.crs.is_geographic:
        return float((x_resolution + y_resolution) / 2.0 * 111320.0)
    return float(fallback)


def metres_to_crs_units(dataset: rasterio.io.DatasetReader, metres: float) -> float:
    if dataset.crs is not None and dataset.crs.is_geographic:
        return float(metres / 111320.0)
    return float(metres)


def read_band_window(source: rasterio.io.DatasetReader, window: Window) -> np.ndarray:
    array = source.read(1, window=window, boundless=True, fill_value=np.nan).astype(np.float32)
    if source.nodata is not None:
        array[array == source.nodata] = np.nan
    array[~np.isfinite(array)] = np.nan
    return array


def reproject_rgb_to_local_grid(
    rgb_source: rasterio.io.DatasetReader,
    target_shape: Tuple[int, int],
    target_transform,
    target_crs,
) -> np.ndarray:
    destination = np.full((3, target_shape[0], target_shape[1]), np.nan, dtype=np.float32)
    for index in range(3):
        reproject(
            source=rasterio.band(rgb_source, index + 1),
            destination=destination[index],
            src_transform=rgb_source.transform,
            src_crs=rgb_source.crs,
            dst_transform=target_transform,
            dst_crs=target_crs,
            resampling=Resampling.bilinear,
            src_nodata=rgb_source.nodata,
            dst_nodata=np.nan,
        )
    finite = destination[np.isfinite(destination)]
    if finite.size and float(np.nanmax(finite)) > 1000:
        destination = destination / 257.0
    return destination


def square_mask(
    shape: Tuple[int, int],
    centre_row: float,
    centre_column: float,
    roi_m: float,
    resolution_m: float,
) -> np.ndarray:
    half = roi_m / max(resolution_m, 1e-12) / 2.0
    row_start = max(0, int(np.floor(centre_row - half)))
    row_stop = min(shape[0], int(np.ceil(centre_row + half)))
    column_start = max(0, int(np.floor(centre_column - half)))
    column_stop = min(shape[1], int(np.ceil(centre_column + half)))
    mask = np.zeros(shape, dtype=bool)
    mask[row_start:row_stop, column_start:column_stop] = True
    return mask


def valid_ratio_threshold(mapping_config: Mapping, roi_m: float) -> float:
    values = mapping_config.get("min_valid_ratio_by_roi", {})
    for key in (f"{roi_m:.2f}", str(roi_m)):
        if key in values:
            return float(values[key])
    return float(mapping_config.get("min_valid_ratio", 0.05))


def load_final_model(config: Mapping, root: Path):
    output_root = resolve_path(root, config["paths"]["output_dir"])
    model_path = output_root / "model_training" / "models" / "GBDT_best_for_SHAP_and_mapping.joblib"
    bundle_path = output_root / "model_training" / "models" / "all_six_models_bundle.joblib"
    selected_path = resolve_path(root, config["modeling"]["selected_features_csv"])
    selected = read_csv(selected_path)
    features = selected["Feature"].dropna().astype(str).tolist()
    model = joblib.load(model_path)
    target_transform = config["modeling"].get("target_transform", "log1p")
    if bundle_path.exists():
        bundle = joblib.load(bundle_path)
        recorded = list(bundle.get("feature_order", []))
        if recorded and recorded != features:
            raise ValueError("Selected feature order differs from the saved model bundle.")
        target_transform = bundle.get("target_transform", target_transform)
    return model, features, target_transform, model_path


def open_rasters(config: Mapping, root: Path) -> Dict[str, rasterio.io.DatasetReader]:
    sources = {}
    for band, path_text in config["paths"]["rasters"].items():
        path = resolve_path(root, path_text)
        if path.exists():
            sources[band] = rasterio.open(path)
    required = {"Green", "Red", "NIR", "RGB"}
    if not required.issubset(sources):
        raise FileNotFoundError("Mapping requires Green, Red, NIR, and RGB rasters.")
    return sources


def grid_centres(source: rasterio.io.DatasetReader, spacing_m: float):
    spacing = metres_to_crs_units(source, spacing_m)
    bounds = source.bounds
    x_values = np.arange(bounds.left + spacing / 2.0, bounds.right, spacing)
    y_values = np.arange(bounds.top - spacing / 2.0, bounds.bottom, -spacing)
    return x_values, y_values, spacing


def extract_grid_features(config: Mapping, root: Path, selected_features: Sequence[str]) -> Tuple[Path, Path]:
    mapping_config = config["mapping"]
    output_dir = resolve_path(root, mapping_config["prediction_output_dir"])
    feature_dir = output_dir / "grid_features"
    feature_dir.mkdir(parents=True, exist_ok=True)
    feature_path = feature_dir / "TN_roi_grid_features.csv"
    metadata_path = feature_dir / "TN_roi_grid_metadata.json"

    sources = open_rasters(config, root)
    working = sources["NIR"]
    resolution_m = get_resolution_m(working, float(mapping_config.get("pixel_size_m_if_unprojected", 0.0065)))
    maximum_roi = max(parse_feature_name(feature)[0] for feature in selected_features)
    padding = float(mapping_config.get("local_padding_m", 0.18))
    half_window_pixels = int(math.ceil((maximum_roi / 2.0 + padding) / resolution_m))
    x_values, y_values, spacing_units = grid_centres(working, float(mapping_config.get("grid_size_m", 0.30)))

    rows = []
    try:
        for grid_row, y_coordinate in enumerate(y_values):
            if grid_row % int(mapping_config.get("print_every_grid_row", 10)) == 0:
                print(f"Grid row {grid_row + 1}/{len(y_values)}")
            for grid_column, x_coordinate in enumerate(x_values):
                source_row, source_column = working.index(x_coordinate, y_coordinate)
                window = Window(
                    col_off=source_column - half_window_pixels,
                    row_off=source_row - half_window_pixels,
                    width=2 * half_window_pixels + 1,
                    height=2 * half_window_pixels + 1,
                )
                local_transform = window_transform(window, working.transform)
                raw = {}
                for band in ("Green", "Red", "RedEdge", "NIR"):
                    if band in sources:
                        raw[band] = read_band_window(sources[band], window)
                shape = raw["NIR"].shape
                rgb = reproject_rgb_to_local_grid(sources["RGB"], shape, local_transform, working.crs)
                multispectral = compute_multispectral_layers(raw)
                rgb_aux, rgb_layers = compute_rgb_layers(rgb)
                layers = {**multispectral, **rgb_layers}
                valid = build_valid_mask(raw)
                cleanv, _, _ = build_cleanv_mask(multispectral, rgb_aux, valid, config["mask"])

                centre_row = source_row - window.row_off
                centre_column = source_column - window.col_off
                check_roi = square_mask(
                    shape,
                    centre_row,
                    centre_column,
                    float(mapping_config.get("check_roi_m", 0.50)),
                    resolution_m,
                )
                check_pixels = int((check_roi & cleanv).sum())
                check_ratio = check_pixels / max(int(check_roi.sum()), 1)
                if check_pixels < int(mapping_config.get("min_bare_pixels", 12)):
                    continue
                if check_ratio < float(mapping_config.get("min_bare_ratio", 0.06)):
                    continue

                record = {
                    "grid_row": grid_row,
                    "grid_column": grid_column,
                    "source_row": source_row,
                    "source_column": source_column,
                    "x": x_coordinate,
                    "y": y_coordinate,
                    "Check_CleanV_pixels": check_pixels,
                    "Check_CleanV_ratio": check_ratio,
                }
                complete = True
                for feature in selected_features:
                    roi_m, layer_name, statistic = parse_feature_name(feature)
                    if layer_name not in layers:
                        complete = False
                        break
                    roi = square_mask(shape, centre_row, centre_column, roi_m, resolution_m)
                    feature_mask = roi & cleanv
                    pixel_count = int(feature_mask.sum())
                    ratio = pixel_count / max(int(roi.sum()), 1)
                    if pixel_count < int(mapping_config.get("min_valid_pixels_in_roi", 12)):
                        complete = False
                        break
                    if ratio < valid_ratio_threshold(mapping_config, roi_m):
                        complete = False
                        break
                    record[feature] = statistic_value(layers[layer_name][feature_mask], statistic)
                if complete:
                    rows.append(record)
    finally:
        for source in sources.values():
            source.close()

    feature_table = pd.DataFrame(rows)
    feature_table.to_csv(feature_path, index=False, encoding="utf-8-sig")
    metadata = {
        "crs": str(working.crs),
        "grid_spacing_m": float(mapping_config.get("grid_size_m", 0.30)),
        "grid_spacing_crs_units": float(spacing_units),
        "x_count": int(len(x_values)),
        "y_count": int(len(y_values)),
        "candidate_grid_count": int(len(x_values) * len(y_values)),
        "retained_grid_count": int(len(feature_table)),
        "first_x_center": float(x_values[0]) if len(x_values) else None,
        "first_y_center": float(y_values[0]) if len(y_values) else None,
        "selected_features": list(selected_features),
    }
    with metadata_path.open("w", encoding="utf-8") as stream:
        json.dump(metadata, stream, ensure_ascii=False, indent=2)
    print(f"Saved: {feature_path}")
    return feature_path, metadata_path


def write_geotiff(prediction: pd.DataFrame, metadata: Mapping, output_path: Path) -> Tuple[np.ndarray, Affine]:
    rows = int(metadata["y_count"])
    columns = int(metadata["x_count"])
    array = np.full((rows, columns), np.nan, dtype=np.float32)
    for _, record in prediction.iterrows():
        array[int(record["grid_row"]), int(record["grid_column"])] = float(record["TN_pred_g_kg"])

    spacing = float(metadata["grid_spacing_crs_units"])
    if prediction.empty:
        raise ValueError("No ROI-grid predictions were retained.")
    first_x = float(metadata["first_x_center"])
    first_y = float(metadata["first_y_center"])
    transform = Affine(spacing, 0, first_x - spacing / 2.0, 0, -spacing, first_y + spacing / 2.0)
    with rasterio.open(
        output_path,
        "w",
        driver="GTiff",
        height=rows,
        width=columns,
        count=1,
        dtype="float32",
        crs=metadata["crs"],
        transform=transform,
        nodata=np.nan,
        compress="lzw",
    ) as destination:
        destination.write(array, 1)
    return array, transform


def normalize_rgb(rgb: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    rgb = np.asarray(rgb, dtype=np.float32)
    outside = (~np.isfinite(rgb).all(axis=0)) | (np.nanmax(np.where(np.isfinite(rgb), rgb, 0), axis=0) <= 1)
    display = np.zeros_like(rgb, dtype=np.float32)
    for index in range(3):
        band = rgb[index]
        valid = np.isfinite(band) & (~outside)
        if int(valid.sum()) < 10:
            continue
        low, high = np.percentile(band[valid], [2, 98])
        display[index] = np.clip((band - low) / (high - low + 1e-6), 0, 1)
    image = np.transpose(display, (1, 2, 0))
    image[outside] = 1.0
    return image, outside


def save_figures(
    prediction: pd.DataFrame,
    raster_array: np.ndarray,
    raster_transform: Affine,
    config: Mapping,
    root: Path,
    output_dir: Path,
) -> None:
    mapping = config["mapping"]
    figure_dir = output_dir / "paper_figures"
    figure_dir.mkdir(parents=True, exist_ok=True)
    vmin = float(mapping.get("color_vmin_g_kg", 0.30))
    vmax = float(mapping.get("color_vmax_g_kg", 1.70))
    norm = Normalize(vmin=vmin, vmax=vmax)
    cmap = mapping.get("cmap", "YlOrRd")
    dpi = int(mapping.get("dpi", 600))

    rgb_path = resolve_path(root, config["paths"]["rasters"]["RGB"])
    with rasterio.open(rgb_path) as source:
        rgb = source.read([1, 2, 3]).astype(np.float32)
        bounds = source.bounds
    rgb_display, _ = normalize_rgb(rgb)

    figure, axis = plt.subplots(figsize=tuple(mapping.get("figure_size", [7.2, 10.0])))
    figure.patch.set_facecolor("white")
    axis.set_facecolor("white")
    axis.imshow(
        rgb_display,
        extent=[bounds.left, bounds.right, bounds.bottom, bounds.top],
        origin="upper",
    )
    scatter = axis.scatter(
        prediction["x"],
        prediction["y"],
        c=prediction["TN_pred_g_kg"],
        s=float(mapping.get("point_size", 5.5)),
        alpha=float(mapping.get("point_alpha", 0.68)),
        edgecolors="none",
        cmap=cmap,
        norm=norm,
    )
    colorbar = figure.colorbar(scatter, ax=axis, fraction=0.036, pad=0.015)
    colorbar.set_label(r"Predicted TN (g kg$^{-1}$)", fontweight="bold")
    if mapping.get("hide_axis", True):
        axis.set_axis_off()
    axis.set_aspect("equal")
    figure.tight_layout()
    figure.savefig(figure_dir / "Fig_TN_ROI_grid_overlay_RGB.png", dpi=dpi, bbox_inches="tight", facecolor="white")
    plt.close(figure)

    masked = np.ma.masked_invalid(raster_array)
    colormap = plt.get_cmap(cmap).copy()
    colormap.set_bad("white")
    rows, columns = raster_array.shape
    extent = [
        raster_transform.c,
        raster_transform.c + raster_transform.a * columns,
        raster_transform.f + raster_transform.e * rows,
        raster_transform.f,
    ]
    figure, axis = plt.subplots(figsize=tuple(mapping.get("figure_size", [7.2, 10.0])))
    figure.patch.set_facecolor("white")
    image = axis.imshow(masked, extent=extent, origin="upper", interpolation="nearest", cmap=colormap, norm=norm)
    colorbar = figure.colorbar(image, ax=axis, fraction=0.036, pad=0.015)
    colorbar.set_label(r"Predicted TN (g kg$^{-1}$)", fontweight="bold")
    if mapping.get("hide_axis", True):
        axis.set_axis_off()
    axis.set_aspect("equal")
    figure.tight_layout()
    figure.savefig(figure_dir / "Fig_TN_ROI_grid_white_background.png", dpi=dpi, bbox_inches="tight", facecolor="white")
    plt.close(figure)


def predict_and_export(
    config: Mapping,
    root: Path,
    model,
    selected_features: Sequence[str],
    target_transform: str,
    feature_path: Path,
    metadata_path: Path,
    model_path: Path,
) -> None:
    mapping = config["mapping"]
    output_dir = resolve_path(root, mapping["prediction_output_dir"])
    prediction_dir = output_dir / "predictions"
    prediction_dir.mkdir(parents=True, exist_ok=True)

    features = read_csv(feature_path)
    with metadata_path.open("r", encoding="utf-8") as stream:
        metadata = json.load(stream)
    X = features[list(selected_features)].apply(pd.to_numeric, errors="coerce")
    complete = X.notna().all(axis=1)
    prediction = features.loc[complete, ["grid_row", "grid_column", "source_row", "source_column", "x", "y"]].copy()
    predicted_model_scale = np.ravel(model.predict(X.loc[complete]))
    predicted_mg_kg = np.clip(inverse_target(predicted_model_scale, target_transform), 0, None)
    prediction["TN_pred_mg_kg"] = predicted_mg_kg
    prediction["TN_pred_g_kg"] = predicted_mg_kg / 1000.0
    prediction.to_csv(prediction_dir / "TN_ROI_grid_prediction_points.csv", index=False, encoding="utf-8-sig")

    raster_array, raster_transform = write_geotiff(
        prediction,
        metadata,
        prediction_dir / "TN_ROI_grid_prediction_g_kg.tif",
    )
    save_figures(prediction, raster_array, raster_transform, config, root, output_dir)

    summary = {
        "model_path": str(model_path),
        "selected_features": list(selected_features),
        "target_transform": target_transform,
        "candidate_grid_count": int(metadata["candidate_grid_count"]),
        "prediction_grid_count": int(len(prediction)),
        "TN_min_g_kg": float(prediction["TN_pred_g_kg"].min()),
        "TN_mean_g_kg": float(prediction["TN_pred_g_kg"].mean()),
        "TN_median_g_kg": float(prediction["TN_pred_g_kg"].median()),
        "TN_max_g_kg": float(prediction["TN_pred_g_kg"].max()),
    }
    with (prediction_dir / "TN_ROI_grid_prediction_summary.json").open("w", encoding="utf-8") as stream:
        json.dump(summary, stream, ensure_ascii=False, indent=2)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config_example.json")
    parser.add_argument("--reuse-grid-features", action="store_true")
    arguments = parser.parse_args()
    config, root = load_config(arguments.config)
    model, features, target_transform, model_path = load_final_model(config, root)

    output_dir = resolve_path(root, config["mapping"]["prediction_output_dir"])
    feature_path = output_dir / "grid_features" / "TN_roi_grid_features.csv"
    metadata_path = output_dir / "grid_features" / "TN_roi_grid_metadata.json"
    if not (arguments.reuse_grid_features and feature_path.exists() and metadata_path.exists()):
        feature_path, metadata_path = extract_grid_features(config, root, features)
    predict_and_export(
        config,
        root,
        model,
        features,
        target_transform,
        feature_path,
        metadata_path,
        model_path,
    )


if __name__ == "__main__":
    main()
