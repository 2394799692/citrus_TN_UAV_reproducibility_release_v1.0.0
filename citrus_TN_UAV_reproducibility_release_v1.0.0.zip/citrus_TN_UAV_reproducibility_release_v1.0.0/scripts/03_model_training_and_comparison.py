# -*- coding: utf-8 -*-
"""Six-model NNDM comparison, repeated ten-fold sensitivity analysis, and model saving."""
from __future__ import annotations

import argparse
import json
import time
import warnings
from pathlib import Path
from typing import Dict, Mapping, Sequence, Tuple

import joblib
import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.cross_decomposition import PLSRegression
from sklearn.ensemble import ExtraTreesRegressor, GradientBoostingRegressor, RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import KFold, ParameterGrid
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVR

from nndm_validation import resolve_nndm_splits

warnings.filterwarnings("ignore")


def load_config(path: str | Path) -> Tuple[dict, Path]:
    path = Path(path).resolve()
    with path.open("r", encoding="utf-8") as stream:
        return json.load(stream), path.parent


def resolve_path(root: Path, value: str | Path) -> Path:
    path = Path(value)
    return path if path.is_absolute() else root / path


def read_csv(path: Path) -> pd.DataFrame:
    for encoding in ("utf-8-sig", "utf-8", "gbk"):
        try:
            return pd.read_csv(path, encoding=encoding)
        except Exception:
            continue
    return pd.read_csv(path)


def rmse(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    return float(np.sqrt(mean_squared_error(y_true, y_pred)))


def rpd(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    error = rmse(y_true, y_pred)
    return float(np.std(y_true, ddof=1) / error) if error > 0 else np.nan


def transform_target(y: np.ndarray, name: str) -> np.ndarray:
    y = np.asarray(y, dtype=float)
    return np.log1p(np.clip(y, 0, None)) if name == "log1p" else y.copy()


def inverse_target(y: np.ndarray, name: str) -> np.ndarray:
    y = np.asarray(y, dtype=float)
    return np.expm1(y) if name == "log1p" else y.copy()


def build_model(model_name: str, parameters: Mapping, random_state: int) -> Pipeline:
    parameters = dict(parameters)
    if model_name == "PLSR":
        return Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
            ("model", PLSRegression(**parameters)),
        ])
    if model_name == "SVR":
        return Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
            ("model", SVR(kernel="rbf", **parameters)),
        ])
    if model_name == "RF":
        parameters["random_state"] = random_state
        estimator = RandomForestRegressor(n_jobs=1, **parameters)
    elif model_name == "ExtraTrees":
        parameters["random_state"] = random_state
        estimator = ExtraTreesRegressor(n_jobs=1, **parameters)
    elif model_name == "GBDT":
        parameters["random_state"] = random_state
        estimator = GradientBoostingRegressor(**parameters)
    elif model_name == "XGBoost":
        try:
            from xgboost import XGBRegressor
        except Exception as exc:
            raise ImportError("xgboost is required for the XGBoost comparison.") from exc
        parameters["random_state"] = random_state
        estimator = XGBRegressor(
            objective="reg:squarederror", n_jobs=1, verbosity=0, **parameters
        )
    else:
        raise ValueError(f"Unknown model: {model_name}")
    return Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("model", estimator),
    ])


def predictions_from_splits(
    model: Pipeline,
    X: np.ndarray,
    y: np.ndarray,
    target_transform: str,
    splits,
) -> np.ndarray:
    transformed = transform_target(y, target_transform)
    predicted_transformed = np.full(len(y), np.nan, dtype=float)
    for train_indices, test_indices in splits:
        fitted = clone(model)
        fitted.fit(X[train_indices], transformed[train_indices])
        predicted_transformed[test_indices] = np.ravel(fitted.predict(X[test_indices]))
    if np.any(~np.isfinite(predicted_transformed)):
        raise RuntimeError("Validation did not return one prediction for every observation.")
    return inverse_target(predicted_transformed, target_transform)


def predictions_from_splitter(
    model: Pipeline,
    X: np.ndarray,
    y: np.ndarray,
    target_transform: str,
    splitter,
) -> np.ndarray:
    return predictions_from_splits(
        model, X, y, target_transform, list(splitter.split(X))
    )


def metrics(y: np.ndarray, prediction: np.ndarray) -> Dict[str, float]:
    return {
        "R2": float(r2_score(y, prediction)),
        "RMSE_mg_kg": rmse(y, prediction),
        "MAE_mg_kg": float(mean_absolute_error(y, prediction)),
        "RPD": rpd(y, prediction),
    }


def search_model(
    model_name: str,
    parameter_grid: Mapping[str, Sequence],
    X: np.ndarray,
    y: np.ndarray,
    target_transform: str,
    random_state: int,
    nndm_splits,
) -> Tuple[pd.DataFrame, dict, np.ndarray, Dict[str, float]]:
    rows = []
    best_key = None
    best_prediction = None
    best_metrics = None
    best_parameters = None
    combinations = list(ParameterGrid(parameter_grid))
    start = time.time()
    for index, parameters in enumerate(combinations, start=1):
        if model_name == "PLSR" and int(parameters["n_components"]) > min(X.shape[1], len(y) - 1):
            continue
        model = build_model(model_name, parameters, random_state)
        prediction = predictions_from_splits(model, X, y, target_transform, nndm_splits)
        current = metrics(y, prediction)
        rows.append({
            "Model": model_name,
            "Combination": index,
            **current,
            "Parameters": json.dumps(parameters, sort_keys=True),
        })
        key = (-current["R2"], current["RMSE_mg_kg"], current["MAE_mg_kg"])
        if best_key is None or key < best_key:
            best_key = key
            best_prediction = prediction.copy()
            best_metrics = current.copy()
            best_parameters = dict(parameters)
        if index % 10 == 0 or index == len(combinations):
            print(
                f"{model_name}: {index}/{len(combinations)} combinations, "
                f"{(time.time() - start) / 60.0:.1f} min"
            )
    if best_metrics is None or best_parameters is None or best_prediction is None:
        raise RuntimeError(f"No valid parameter combination was evaluated for {model_name}.")
    return pd.DataFrame(rows), best_parameters, best_prediction, best_metrics


def repeated_tenfold(
    model: Pipeline,
    X: np.ndarray,
    y: np.ndarray,
    target_transform: str,
    repeats: int,
    random_state: int,
) -> pd.DataFrame:
    rows = []
    for repeat in range(repeats):
        splitter = KFold(n_splits=10, shuffle=True, random_state=random_state + repeat)
        prediction = predictions_from_splitter(model, X, y, target_transform, splitter)
        rows.append({"Repeat": repeat + 1, **metrics(y, prediction)})
    return pd.DataFrame(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config_example.json")
    arguments = parser.parse_args()
    config, root = load_config(arguments.config)

    output_root = resolve_path(root, config["paths"]["output_dir"])
    feature_selection_dir = output_root / "feature_selection"
    output_dir = output_root / "model_training"
    model_dir = output_dir / "models"
    search_dir = output_dir / "search_results"
    for directory in (output_dir, model_dir, search_dir):
        directory.mkdir(parents=True, exist_ok=True)

    wide = read_csv(feature_selection_dir / "wide_modeling_table.csv")
    selected = read_csv(resolve_path(root, config["modeling"]["selected_features_csv"]))
    if "Feature" not in selected.columns:
        raise ValueError("The selected-feature table must contain a 'Feature' column.")
    features = selected["Feature"].dropna().astype(str).tolist()
    target = config["analysis"]["main_target"]
    missing = [feature for feature in features if feature not in wide.columns]
    if missing:
        raise ValueError(f"Selected features are absent from the wide table: {missing}")

    data = wide.loc[wide[target].notna()].copy().reset_index(drop=True)
    X = data[features].apply(pd.to_numeric, errors="coerce").to_numpy(float)
    y = pd.to_numeric(data[target], errors="coerce").to_numpy(float)
    sample_ids = data["Sample_ID"].astype(str).to_numpy()
    nndm_splits, fold_plan, validation_info = resolve_nndm_splits(
        config, root, sample_ids
    )
    fold_plan.to_csv(output_dir / "nndm_folds_used.csv", index=False, encoding="utf-8-sig")

    target_transform = config["modeling"].get("target_transform", "log1p")
    random_state = int(config["modeling"].get("random_state", 2026))
    summary_rows = []
    prediction_rows = []
    best_models = {}
    repeated_tables = []

    for model_name in ("GBDT", "XGBoost", "RF", "ExtraTrees", "SVR", "PLSR"):
        grid = config["modeling"]["model_grids"][model_name]
        search_table, best_parameters, prediction, best_metric = search_model(
            model_name, grid, X, y, target_transform, random_state, nndm_splits
        )
        search_table.to_csv(
            search_dir / f"{model_name}_NNDM_parameter_search.csv",
            index=False,
            encoding="utf-8-sig",
        )

        model = build_model(model_name, best_parameters, random_state)
        model.fit(X, transform_target(y, target_transform))
        joblib.dump(model, model_dir / f"{model_name}_best_pipeline.joblib")
        best_models[model_name] = model

        repeated_mean = np.nan
        repeated_sd = np.nan
        if bool(config["modeling"].get("run_repeated_tenfold", True)):
            repeat_count = int(config["modeling"].get("repeated_tenfold_repeats", 100))
            repeated = repeated_tenfold(
                model, X, y, target_transform, repeat_count, random_state
            )
            repeated["Model"] = model_name
            repeated_tables.append(repeated)
            repeated.to_csv(
                output_dir / f"{model_name}_repeated_tenfold.csv",
                index=False,
                encoding="utf-8-sig",
            )
            repeated_mean = float(repeated["R2"].mean())
            repeated_sd = float(repeated["R2"].std(ddof=1))

        summary_rows.append({
            "Model": model_name,
            "NNDM_R2": best_metric["R2"],
            "RMSE_mg_kg": best_metric["RMSE_mg_kg"],
            "MAE_mg_kg": best_metric["MAE_mg_kg"],
            "RPD": best_metric["RPD"],
            "RMSE_g_kg": best_metric["RMSE_mg_kg"] / 1000.0,
            "MAE_g_kg": best_metric["MAE_mg_kg"] / 1000.0,
            "Repeated_10fold_R2_mean": repeated_mean,
            "Repeated_10fold_R2_sd": repeated_sd,
            "Best_parameters": json.dumps(best_parameters, sort_keys=True),
        })
        for sample_id, observed, predicted in zip(sample_ids, y, prediction):
            prediction_rows.append({
                "Model": model_name,
                "Sample_ID": sample_id,
                "Observed_TN_mg_kg": observed,
                "Predicted_TN_mg_kg": predicted,
                "Observed_TN_g_kg": observed / 1000.0,
                "Predicted_TN_g_kg": predicted / 1000.0,
                "Residual_mg_kg": predicted - observed,
            })

    summary = pd.DataFrame(summary_rows).sort_values("NNDM_R2", ascending=False)
    predictions = pd.DataFrame(prediction_rows)
    summary.to_csv(output_dir / "six_model_NNDM_summary.csv", index=False, encoding="utf-8-sig")
    predictions.to_csv(
        output_dir / "six_model_NNDM_predictions.csv", index=False, encoding="utf-8-sig"
    )
    if repeated_tables:
        pd.concat(repeated_tables, ignore_index=True).to_csv(
            output_dir / "all_models_repeated_tenfold.csv",
            index=False,
            encoding="utf-8-sig",
        )

    bundle = {
        "feature_order": features,
        "target_column": target,
        "target_transform": target_transform,
        "sample_n": int(len(y)),
        "validation": validation_info,
        "models": best_models,
        "summary": summary.to_dict(orient="records"),
    }
    joblib.dump(bundle, model_dir / "all_six_models_bundle.joblib")
    if "GBDT" in best_models:
        joblib.dump(best_models["GBDT"], model_dir / "GBDT_best_for_SHAP_and_mapping.joblib")

    with (output_dir / "model_training_manifest.json").open("w", encoding="utf-8") as stream:
        json.dump(
            {
                "feature_order": features,
                "target_column": target,
                "target_transform": target_transform,
                "sample_n": int(len(y)),
                "validation": validation_info,
                "output_summary": str(output_dir / "six_model_NNDM_summary.csv"),
            },
            stream,
            ensure_ascii=False,
            indent=2,
        )
    print(summary.to_string(index=False))
    print(f"Saved models and tables to: {output_dir}")


if __name__ == "__main__":
    main()
