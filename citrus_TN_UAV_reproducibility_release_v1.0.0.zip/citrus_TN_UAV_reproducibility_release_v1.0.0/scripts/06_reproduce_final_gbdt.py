# -*- coding: utf-8 -*-
"""Reproduce the final five-feature TN GBDT result under NNDM validation."""
from __future__ import annotations

import argparse
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.pipeline import Pipeline

from nndm_validation import load_fold_plan, read_table


def parse_parameters(path: Path):
    table = read_table(path)
    parameters = {}
    metadata = {}
    for _, row in table.iterrows():
        key = str(row["Parameter"])
        value = row["Value"]
        if key in {"target_transform", "validation"}:
            metadata[key] = str(value)
            continue
        if isinstance(value, str):
            text = value.strip()
            try:
                value = float(text) if any(ch in text for ch in ".eE") else int(text)
            except Exception:
                pass
        parameters[key] = value
    return parameters, metadata


def rmse(y_true, y_pred):
    return float(np.sqrt(mean_squared_error(y_true, y_pred)))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--data",
        default="data/reproducibility_current/final_5_features_TN_modeling_data_current.csv",
    )
    parser.add_argument(
        "--params",
        default="data/reproducibility_current/final_GBDT_reproduction_parameters_current.csv",
    )
    parser.add_argument(
        "--fold-plan",
        default="data/reproducibility_current/nndm_folds_current.csv",
        help="Archived anonymised NNDM fold plan used for the manuscript result.",
    )
    parser.add_argument("--output", default="outputs/minimal_reproduction_current")
    parser.add_argument("--random-state", type=int, default=2026)
    arguments = parser.parse_args()

    data_path = Path(arguments.data)
    parameter_path = Path(arguments.params)
    fold_plan_path = Path(arguments.fold_plan)
    output_dir = Path(arguments.output)
    output_dir.mkdir(parents=True, exist_ok=True)

    data = read_table(data_path)
    parameters, metadata = parse_parameters(parameter_path)
    parameters["random_state"] = arguments.random_state
    target_transform = metadata.get("target_transform", "log1p")

    sample_column = "Sample_ID"
    target_column = "TN_mg_kg"
    feature_columns = [c for c in data.columns if c not in {sample_column, target_column}]
    X = data[feature_columns].apply(pd.to_numeric, errors="coerce").to_numpy(float)
    y = pd.to_numeric(data[target_column], errors="coerce").to_numpy(float)
    sample_ids = data[sample_column].astype(str).to_numpy()
    splits, normalized_plan = load_fold_plan(fold_plan_path, sample_ids)

    pipeline = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("model", GradientBoostingRegressor(**parameters)),
    ])
    transformed = np.log1p(np.clip(y, 0, None)) if target_transform == "log1p" else y.copy()
    predicted_transformed = np.full(len(y), np.nan, dtype=float)
    fold_rows = []
    for fold_id, (train_idx, test_idx) in enumerate(splits, start=1):
        model = clone(pipeline)
        model.fit(X[train_idx], transformed[train_idx])
        predicted_transformed[test_idx] = np.ravel(model.predict(X[test_idx]))
        fold_rows.append({
            "Fold_ID": fold_id,
            "Test_Sample_ID": ";".join(sample_ids[test_idx]),
            "Train_N": int(len(train_idx)),
            "Test_N": int(len(test_idx)),
        })
    prediction = np.expm1(predicted_transformed) if target_transform == "log1p" else predicted_transformed

    error = rmse(y, prediction)
    mae = float(mean_absolute_error(y, prediction))
    metrics = {
        "Model": "GBDT",
        "Validation": "Prediction-domain-oriented NNDM spatial validation",
        "Sample_N": int(len(y)),
        "Feature_N": int(len(feature_columns)),
        "NNDM_R2": float(r2_score(y, prediction)),
        "RMSE_mg_kg": error,
        "RMSE_g_kg": error / 1000.0,
        "MAE_mg_kg": mae,
        "MAE_g_kg": mae / 1000.0,
        "RPD": float(np.std(y, ddof=1) / error),
        "Mean_train_N": float(normalized_plan["Train_N"].mean()),
        "Minimum_train_N": int(normalized_plan["Train_N"].min()),
        "Target_transform": target_transform,
        "Features": ";".join(feature_columns),
        "Parameters": "; ".join(f"{key}={value}" for key, value in parameters.items()),
    }

    predictions = pd.DataFrame({
        "Sample_ID": sample_ids,
        "Observed_TN_mg_kg": y,
        "Predicted_TN_mg_kg": prediction,
        "Observed_TN_g_kg": y / 1000.0,
        "Predicted_TN_g_kg": prediction / 1000.0,
        "Residual_mg_kg": prediction - y,
        "Absolute_error_mg_kg": np.abs(prediction - y),
    })
    predictions.to_csv(
        output_dir / "final_GBDT_NNDM_predictions.csv", index=False, encoding="utf-8-sig"
    )
    pd.DataFrame([metrics]).to_csv(
        output_dir / "final_GBDT_NNDM_metrics.csv", index=False, encoding="utf-8-sig"
    )
    normalized_plan.to_csv(
        output_dir / "final_GBDT_NNDM_folds.csv", index=False, encoding="utf-8-sig"
    )

    pipeline.fit(X, transformed)
    joblib.dump(
        {
            "model": pipeline,
            "feature_order": feature_columns,
            "target_transform": target_transform,
            "validation": "Prediction-domain-oriented NNDM spatial validation",
            "fold_plan": str(fold_plan_path),
            "metrics": metrics,
        },
        output_dir / "final_GBDT_full_fit_bundle.joblib",
    )
    print(pd.DataFrame([metrics]).to_string(index=False))
    print(f"Saved outputs to: {output_dir}")


if __name__ == "__main__":
    main()
