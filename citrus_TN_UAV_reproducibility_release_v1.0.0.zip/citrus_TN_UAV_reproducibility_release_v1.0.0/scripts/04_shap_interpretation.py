# -*- coding: utf-8 -*-
"""SHAP interpretation of the saved final GBDT pipeline."""
from __future__ import annotations

import argparse
import json
import warnings
from pathlib import Path
from typing import Tuple

import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.pipeline import Pipeline

warnings.filterwarnings("ignore")
plt.rcParams["font.family"] = "Times New Roman"
plt.rcParams["mathtext.fontset"] = "stix"
plt.rcParams["axes.unicode_minus"] = False


def load_config(path: str | Path) -> Tuple[dict, Path]:
    path = Path(path).resolve()
    with path.open("r", encoding="utf-8") as stream:
        config = json.load(stream)
    return config, path.parent


def resolve_path(root: Path, value: str | Path) -> Path:
    path = Path(value)
    return path if path.is_absolute() else root / path


def read_csv(path: Path) -> pd.DataFrame:
    for encoding in ("utf-8-sig", "utf-8", "gbk"):
        try:
            return pd.read_csv(path, encoding=encoding)
        except Exception:
            continue
    return pd.read_csv(path)


def short_label(feature: str) -> str:
    text = feature
    for roi in ("R0.30m__", "R0.50m__", "R0.80m__"):
        if text.startswith(roi):
            suffix = roi[1:5]
            text = text[len(roi):] + "_" + suffix
            break
    return text.replace("RGB_", "").replace("Visible_Brightness_GR", "VisBright_GR")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config_example.json")
    arguments = parser.parse_args()
    config, root = load_config(arguments.config)

    try:
        import shap
    except Exception as exc:
        raise ImportError("Install shap to run this module.") from exc

    output_root = resolve_path(root, config["paths"]["output_dir"])
    feature_selection_dir = output_root / "feature_selection"
    model_dir = output_root / "model_training" / "models"
    output_dir = output_root / "shap_interpretation"
    output_dir.mkdir(parents=True, exist_ok=True)

    wide = read_csv(feature_selection_dir / "wide_modeling_table.csv")
    selected = read_csv(resolve_path(root, config["modeling"]["selected_features_csv"]))
    features = selected["Feature"].dropna().astype(str).tolist()
    target = config["analysis"]["main_target"]
    data = wide.loc[wide[target].notna()].copy()
    X_raw = data[features].apply(pd.to_numeric, errors="coerce").to_numpy(dtype=float)

    saved = joblib.load(model_dir / "GBDT_best_for_SHAP_and_mapping.joblib")
    if not isinstance(saved, Pipeline):
        raise TypeError("The saved GBDT object must be a scikit-learn Pipeline.")
    if "imputer" not in saved.named_steps or "model" not in saved.named_steps:
        raise KeyError("The saved pipeline must contain 'imputer' and 'model' steps.")

    X = saved.named_steps["imputer"].transform(X_raw)
    estimator = saved.named_steps["model"]
    explainer = shap.TreeExplainer(estimator)
    shap_values = np.asarray(explainer.shap_values(X), dtype=float)
    labels = [short_label(feature) for feature in features]

    importance = pd.DataFrame({
        "Feature": features,
        "Feature_label": labels,
        "Mean_abs_SHAP": np.mean(np.abs(shap_values), axis=0),
        "Mean_SHAP": np.mean(shap_values, axis=0),
    }).sort_values("Mean_abs_SHAP", ascending=False)
    importance["Contribution_percent"] = 100.0 * importance["Mean_abs_SHAP"] / importance["Mean_abs_SHAP"].sum()
    importance.to_csv(output_dir / "shap_feature_importance.csv", index=False, encoding="utf-8-sig")

    sample_table = pd.DataFrame({
        "Sample_ID": data["Sample_ID"].astype(str).to_numpy(),
        "Observed_target": pd.to_numeric(data[target], errors="coerce").to_numpy(dtype=float),
    })
    for index, (feature, label) in enumerate(zip(features, labels)):
        sample_table[f"Value_{label}"] = X[:, index]
        sample_table[f"SHAP_{label}"] = shap_values[:, index]
    sample_table.to_csv(output_dir / "shap_values_by_sample.csv", index=False, encoding="utf-8-sig")

    figure, axis = plt.subplots(figsize=(6.2, 4.2))
    ordered = importance.sort_values("Mean_abs_SHAP")
    axis.barh(ordered["Feature_label"], ordered["Mean_abs_SHAP"], color="#9bd7d2", edgecolor="#5ab4ac")
    axis.set_xlabel("Mean |SHAP value|", fontweight="bold")
    figure.tight_layout()
    figure.savefig(output_dir / "Fig_SHAP_mean_importance.png", dpi=600, bbox_inches="tight")
    plt.close(figure)

    shap.summary_plot(shap_values, X, feature_names=labels, show=False)
    current = plt.gcf()
    current.set_size_inches(7.0, 4.6)
    current.tight_layout()
    current.savefig(output_dir / "Fig_SHAP_beeswarm.png", dpi=600, bbox_inches="tight")
    plt.close(current)

    print(f"Saved SHAP outputs to: {output_dir}")


if __name__ == "__main__":
    main()
