# -*- coding: utf-8 -*-
"""Project and translation-align a prediction grid to sample coordinates.

This portable version is based on the coordinate-preparation script used for
the manuscript. It can project longitude/latitude grid coordinates to the local
UTM zone and estimate a translation-only alignment to projected sample
coordinates. It never rotates, scales, or deforms the grid.

Use only when the two files describe the same site and differ by CRS and/or a
fixed coordinate offset. Inspect the JSON diagnostics and spatial overlay
before generating NNDM folds.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Tuple

import numpy as np
import pandas as pd
from pyproj import CRS, Transformer
from scipy.optimize import differential_evolution, minimize
from scipy.spatial import cKDTree

from nndm_validation import read_table

COORDINATE_PAIRS = [
    ("x", "y"), ("X", "Y"), ("Longitude", "Latitude"),
    ("longitude", "latitude"), ("Lon", "Lat"), ("lon", "lat"),
    ("Easting", "Northing"), ("easting", "northing"),
    ("E_align", "N_align"), ("Coord_X", "Coord_Y"),
]


def detect_pair(frame: pd.DataFrame, x_col: str | None, y_col: str | None) -> Tuple[str, str]:
    if x_col and y_col:
        if x_col not in frame.columns or y_col not in frame.columns:
            raise ValueError(f"Coordinate columns not found: {x_col}, {y_col}")
        return x_col, y_col
    for x_name, y_name in COORDINATE_PAIRS:
        if x_name in frame.columns and y_name in frame.columns:
            values = frame[[x_name, y_name]].apply(pd.to_numeric, errors="coerce").dropna()
            if len(values) >= 3:
                return x_name, y_name
    raise ValueError(f"No coordinate pair detected. Columns={list(frame.columns)}")


def looks_geographic(xy: np.ndarray) -> bool:
    return bool(
        np.all((-180 <= xy[:, 0]) & (xy[:, 0] <= 180))
        and np.all((-90 <= xy[:, 1]) & (xy[:, 1] <= 90))
        and np.ptp(xy[:, 0]) < 5
        and np.ptp(xy[:, 1]) < 5
    )


def project_grid(xy: np.ndarray):
    if not looks_geographic(xy):
        return xy.copy(), {"source_type": "projected_or_planar", "metric_crs": "unchanged"}
    lon = float(np.median(xy[:, 0]))
    lat = float(np.median(xy[:, 1]))
    zone = int(math.floor((lon + 180) / 6) + 1)
    epsg = (32600 if lat >= 0 else 32700) + zone
    crs = CRS.from_epsg(epsg)
    transformer = Transformer.from_crs("EPSG:4326", crs, always_xy=True)
    east, north = transformer.transform(xy[:, 0], xy[:, 1])
    return np.column_stack([east, north]), {
        "source_type": "geographic",
        "source_crs": "EPSG:4326",
        "metric_crs": crs.to_string(),
        "median_longitude": lon,
        "median_latitude": lat,
    }


def overlap_fraction(samples: np.ndarray, grid: np.ndarray, margin: float = 5.0) -> float:
    low = np.min(grid, axis=0) - margin
    high = np.max(grid, axis=0) + margin
    return float(np.mean(np.all((samples >= low) & (samples <= high), axis=1)))


def objective_factory(samples: np.ndarray, grid: np.ndarray):
    tree = cKDTree(grid)
    grid_min = np.min(grid, axis=0)
    grid_max = np.max(grid, axis=0)

    def objective(shift):
        shift = np.asarray(shift, dtype=float)
        distances = tree.query(samples - shift, k=1)[0]
        fit = float(np.median(distances) + 0.30 * np.quantile(distances, 0.80))
        low = grid_min + shift
        high = grid_max + shift
        below = np.maximum(low - samples, 0.0)
        above = np.maximum(samples - high, 0.0)
        penalty = 2.0 * float(np.mean(np.linalg.norm(below + above, axis=1)))
        return fit + penalty

    return objective


def estimate_translation(samples: np.ndarray, grid: np.ndarray, random_state: int = 2026):
    centre = np.median(samples, axis=0) - np.median(grid, axis=0)
    span = max(
        float(np.linalg.norm(np.ptp(samples, axis=0))),
        float(np.linalg.norm(np.ptp(grid, axis=0))),
        30.0,
    )
    half_width = min(500.0, span)
    bounds = [
        (float(centre[0] - half_width), float(centre[0] + half_width)),
        (float(centre[1] - half_width), float(centre[1] + half_width)),
    ]
    objective = objective_factory(samples, grid)
    global_result = differential_evolution(
        objective, bounds=bounds, seed=random_state, polish=False,
        workers=1, updating="immediate", maxiter=120, popsize=12, tol=1e-7,
    )
    local_result = minimize(
        objective, x0=global_result.x, method="Powell", bounds=bounds,
        options={"maxiter": 1000, "xtol": 1e-7, "ftol": 1e-7},
    )
    shift = np.asarray(local_result.x, dtype=float)
    aligned = grid + shift
    distances = cKDTree(aligned).query(samples, k=1)[0]
    return aligned, {
        "translation_x_m": float(shift[0]),
        "translation_y_m": float(shift[1]),
        "median_sample_to_grid_m": float(np.median(distances)),
        "q80_sample_to_grid_m": float(np.quantile(distances, 0.80)),
        "maximum_sample_to_grid_m": float(np.max(distances)),
        "sample_inside_grid_bbox_fraction": overlap_fraction(samples, aligned),
        "objective_value": float(objective(shift)),
        "global_optimizer_success": bool(global_result.success),
        "local_optimizer_success": bool(local_result.success),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--sample-coordinates", required=True)
    parser.add_argument("--prediction-grid", required=True)
    parser.add_argument("--sample-x", default="Easting")
    parser.add_argument("--sample-y", default="Northing")
    parser.add_argument("--grid-x")
    parser.add_argument("--grid-y")
    parser.add_argument("--output", required=True)
    parser.add_argument("--diagnostics")
    parser.add_argument("--output-x", default="Easting")
    parser.add_argument("--output-y", default="Northing")
    parser.add_argument("--random-state", type=int, default=2026)
    args = parser.parse_args()

    samples = read_table(args.sample_coordinates)
    grid = read_table(args.prediction_grid)
    if args.sample_x not in samples.columns or args.sample_y not in samples.columns:
        raise ValueError("Sample coordinate columns were not found.")
    gx, gy = detect_pair(grid, args.grid_x, args.grid_y)
    sample_xy = samples[[args.sample_x, args.sample_y]].apply(pd.to_numeric, errors="coerce").dropna().to_numpy(float)
    numeric = grid[[gx, gy]].apply(pd.to_numeric, errors="coerce")
    valid = numeric[gx].notna() & numeric[gy].notna()
    grid_xy = numeric.loc[valid, [gx, gy]].to_numpy(float)
    metric_grid, projection = project_grid(grid_xy)

    direct_distances = cKDTree(metric_grid).query(sample_xy, k=1)[0]
    if overlap_fraction(sample_xy, metric_grid) >= 0.75 and np.median(direct_distances) <= 8.0:
        aligned = metric_grid
        registration = {
            "mode": "direct_projection_no_translation",
            "translation_x_m": 0.0,
            "translation_y_m": 0.0,
            "median_sample_to_grid_m": float(np.median(direct_distances)),
            "sample_inside_grid_bbox_fraction": overlap_fraction(sample_xy, metric_grid),
        }
    else:
        aligned, registration = estimate_translation(sample_xy, metric_grid, args.random_state)
        registration["mode"] = "translation_only_point_set_registration"

    if registration["sample_inside_grid_bbox_fraction"] < 0.75 or registration["median_sample_to_grid_m"] > 8.0:
        raise RuntimeError(
            "Translation-only alignment remains implausible. Confirm that the sample and grid files "
            "describe the same site and inspect their coordinate systems."
        )

    output = grid.copy()
    output[args.output_x] = np.nan
    output[args.output_y] = np.nan
    output.loc[valid, args.output_x] = aligned[:, 0]
    output.loc[valid, args.output_y] = aligned[:, 1]
    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output.to_csv(output_path, index=False, encoding="utf-8-sig")

    diagnostics_path = Path(args.diagnostics) if args.diagnostics else output_path.with_suffix(".diagnostics.json")
    diagnostics_path.write_text(
        json.dumps(
            {
                "sample_coordinates": str(Path(args.sample_coordinates)),
                "source_prediction_grid": str(Path(args.prediction_grid)),
                "output_prediction_grid": str(output_path),
                "source_coordinate_columns": [gx, gy],
                "output_coordinate_columns": [args.output_x, args.output_y],
                "projection": projection,
                "registration": registration,
                "method_note": "Projection followed by translation only; no rotation, scaling, or deformation.",
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    print(f"Aligned grid: {output_path}")
    print(f"Diagnostics: {diagnostics_path}")


if __name__ == "__main__":
    main()
