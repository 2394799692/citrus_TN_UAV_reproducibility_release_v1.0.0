# -*- coding: utf-8 -*-
"""Shared CleanV, feature-formula, and ROI-statistics functions.

This module is imported by both sample-centred feature extraction and ROI-grid
mapping so that model development and spatial deployment use exactly the same
pixel-level definitions.

Data-source convention
----------------------
- Green, Red, RedEdge, and NIR denote multispectral reflectance bands.
- RGB_R, RGB_G, and RGB_B denote channels of the RGB orthomosaic resampled to
  the multispectral working grid.
- ``Visible_Brightness_GR`` and ``Redness_RG`` are multispectral Green/Red
  features. Their names intentionally do not contain the ``RGB_`` prefix.
- ``RGB_Gray``, ``RGB_ExB``, and ``RGB_b_chroma`` are RGB-camera features.

Only two pixel schemes are defined in the release: ``Raw`` and ``CleanV``.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, Mapping, Sequence, Tuple

import numpy as np
import pandas as pd
from skimage import morphology
from skimage.feature import graycomatrix, graycoprops

EPS = 1e-6
SUPPORTED_MASKS = ("Raw", "CleanV")
SUPPORTED_STATS = ("mean", "median", "std", "cv", "min", "max", "p10", "p25", "p50", "p75", "p90")


@dataclass(frozen=True)
class FeatureDefinition:
    name: str
    source: str
    formula: str
    description: str
    unit: str = "processed image value"


def safe_div(a: np.ndarray, b: np.ndarray, eps: float = EPS) -> np.ndarray:
    return np.asarray(a, dtype=np.float32) / (np.asarray(b, dtype=np.float32) + eps)


def normalized_difference(a: np.ndarray, b: np.ndarray, eps: float = EPS) -> np.ndarray:
    a = np.asarray(a, dtype=np.float32)
    b = np.asarray(b, dtype=np.float32)
    return (a - b) / (a + b + eps)


def normalize_local(arr: np.ndarray) -> np.ndarray:
    """Robust 2nd--98th percentile normalization used only by CleanV."""
    arr = np.asarray(arr, dtype=np.float32)
    valid = np.isfinite(arr) & (arr > 0)
    if int(valid.sum()) < 10:
        return np.zeros_like(arr, dtype=np.float32)
    low, high = np.percentile(arr[valid], [2, 98])
    if high <= low:
        return np.zeros_like(arr, dtype=np.float32)
    return np.clip((arr - low) / (high - low + EPS), 0, 1).astype(np.float32)


def _finite_float32(layers: Mapping[str, np.ndarray]) -> Dict[str, np.ndarray]:
    return {
        name: np.where(np.isfinite(value), value, np.nan).astype(np.float32)
        for name, value in layers.items()
    }


def compute_multispectral_layers(raw: Mapping[str, np.ndarray]) -> Dict[str, np.ndarray]:
    """Compute multispectral pixel-level bands, transforms, and indices."""
    green = np.asarray(raw["Green"], dtype=np.float32)
    red = np.asarray(raw["Red"], dtype=np.float32)
    rededge = np.asarray(raw.get("RedEdge", red), dtype=np.float32)
    nir = np.asarray(raw["NIR"], dtype=np.float32)

    layers = {
        "Band_Green": green,
        "Band_Red": red,
        "Band_RedEdge": rededge,
        "Band_NIR": nir,
        "MS_Brightness": (green + red + rededge + nir) / 4.0,
        "Visible_Brightness_GR": (green + red) / 2.0,
        "Redness_RG": normalized_difference(red, green),
        "Green_Red_Ratio": safe_div(green, red),
        "Red_Green_Ratio": safe_div(red, green),
        "NDVI": normalized_difference(nir, red),
        "GNDVI": normalized_difference(nir, green),
        "NDRE": normalized_difference(nir, rededge),
        "RE_R_NDI": normalized_difference(rededge, red),
        "RVI": safe_div(nir, red),
        "DVI": nir - red,
        "SAVI": 1.5 * (nir - red) / (nir + red + 0.5 + EPS),
        "OSAVI": 1.16 * (nir - red) / (nir + red + 0.16 + EPS),
        "EVI2": 2.5 * (nir - red) / (nir + 2.4 * red + 1.0 + EPS),
        "NIR_Red_Ratio": safe_div(nir, red),
        "NIR_RE_Ratio": safe_div(nir, rededge),
        "RE_Red_Ratio": safe_div(rededge, red),
        "NIR_minus_Red": nir - red,
        "NIR_minus_Green": nir - green,
        "RE_minus_Red": rededge - red,
        "CIgreen": safe_div(nir, green) - 1.0,
        "CIrededge": safe_div(nir, rededge) - 1.0,
    }

    msavi_inner = np.clip((2.0 * nir + 1.0) ** 2 - 8.0 * (nir - red), 0, None)
    layers["MSAVI2"] = (2.0 * nir + 1.0 - np.sqrt(msavi_inner)) / 2.0

    for name, band in {
        "Green": green,
        "Red": red,
        "RedEdge": rededge,
        "NIR": nir,
    }.items():
        positive = np.clip(band, EPS, None)
        layers[f"Log_{name}"] = np.log(positive)
        layers[f"Sqrt_{name}"] = np.sqrt(positive)

    return _finite_float32(layers)


def compute_rgb_layers(rgb: np.ndarray | None) -> Tuple[Dict[str, np.ndarray], Dict[str, np.ndarray]]:
    """Compute RGB-camera layers and auxiliary normalized channels."""
    if rgb is None:
        return {}, {}
    rgb = np.asarray(rgb, dtype=np.float32)
    if rgb.ndim != 3 or rgb.shape[0] < 3:
        raise ValueError("RGB input must have shape (3, rows, columns).")

    red = rgb[0]
    green = rgb[1]
    blue = rgb[2]
    red_n = normalize_local(red)
    green_n = normalize_local(green)
    blue_n = normalize_local(blue)

    total = red + green + blue + EPS
    r = red / total
    g = green / total
    b = blue / total

    aux = {
        "R_norm_local": red_n,
        "G_norm_local": green_n,
        "B_norm_local": blue_n,
        "r_chroma": r,
        "g_chroma": g,
        "b_chroma": b,
    }
    layers = {
        "RGB_R_raw": red,
        "RGB_G_raw": green,
        "RGB_B_raw": blue,
        "RGB_Gray": (red + green + blue) / 3.0,
        "RGB_r_chroma": r,
        "RGB_g_chroma": g,
        "RGB_b_chroma": b,
        "RGB_ExG": 2.0 * g - r - b,
        "RGB_ExR": 1.4 * r - g,
        "RGB_ExB": 1.4 * b - g,
        "RGB_ExGR": (2.0 * g - r - b) - (1.4 * r - g),
        "RGB_NGRDI": normalized_difference(green, red),
        "RGB_VARI": (green - red) / (green + red - blue + EPS),
        "RGB_RGBVI": (green ** 2 - red * blue) / (green ** 2 + red * blue + EPS),
    }
    return _finite_float32(aux), _finite_float32(layers)


def build_valid_mask(raw: Mapping[str, np.ndarray]) -> np.ndarray:
    """Valid multispectral pixels shared by Raw and CleanV."""
    valid = np.ones_like(np.asarray(raw["NIR"]), dtype=bool)
    required = ["Green", "Red", "NIR"]
    if "RedEdge" in raw:
        required.append("RedEdge")
    for key in required:
        band = np.asarray(raw[key])
        valid &= np.isfinite(band) & (band > 0)
    return valid


def validate_mask_versions(versions: Iterable[str]) -> Tuple[str, ...]:
    versions = tuple(str(v) for v in versions)
    unsupported = sorted(set(versions) - set(SUPPORTED_MASKS))
    if unsupported:
        raise ValueError(
            f"Unsupported mask name(s): {unsupported}. "
            f"This release defines only {SUPPORTED_MASKS}."
        )
    return versions


def build_cleanv_mask(
    ms_layers: Mapping[str, np.ndarray],
    rgb_aux: Mapping[str, np.ndarray],
    valid_mask: np.ndarray,
    mask_config: Mapping[str, Mapping[str, float]],
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Return retained bare soil, vegetation, and coloured-marker masks."""
    vegetation_cfg = mask_config["vegetation"]
    marker_cfg = mask_config["marker"]

    ndvi = ms_layers["NDVI"]
    gndvi = ms_layers["GNDVI"]
    ndre = ms_layers["NDRE"]

    # Manuscript-aligned strong-vegetation rule: all three multispectral
    # conditions must be satisfied simultaneously.
    vegetation_ms = (
        (ndvi > vegetation_cfg["ndvi_strong"])
        & (gndvi > vegetation_cfg["gndvi_strong"])
        & (ndre > vegetation_cfg["ndre_strong"])
    )
    vegetation = vegetation_ms.copy()
    marker = np.zeros_like(valid_mask, dtype=bool)

    if rgb_aux:
        red_n = rgb_aux["R_norm_local"]
        green_n = rgb_aux["G_norm_local"]
        blue_n = rgb_aux["B_norm_local"]
        r = rgb_aux["r_chroma"]
        g = rgb_aux["g_chroma"]
        b = rgb_aux["b_chroma"]
        exg = 2.0 * g - r - b

        rgb_green = (
            ((green_n - red_n) > vegetation_cfg["rgb_green_margin"])
            & ((green_n - blue_n) > vegetation_cfg["rgb_green_blue_margin"])
            & (exg > vegetation_cfg["exg_strong"])
        )
        weak_spectral_support = (ndvi > vegetation_cfg["ndvi_weak"]) | (gndvi > vegetation_cfg["gndvi_weak"])
        vegetation |= rgb_green & weak_spectral_support

        blue_marker = (
            (b > marker_cfg["blue_chroma"])
            & (blue_n > marker_cfg["blue_norm"])
            & ((blue_n - red_n) > marker_cfg["blue_margin"])
            & ((blue_n - green_n) > marker_cfg["blue_margin"] * 0.6)
        )
        red_marker = (
            (r > marker_cfg["red_chroma"])
            & (red_n > marker_cfg["red_norm"])
            & ((red_n - green_n) > marker_cfg["red_margin"])
            & ((red_n - blue_n) > marker_cfg["red_margin"])
        )
        marker = (blue_marker | red_marker) & valid_mask

        marker_dilate = int(marker_cfg.get("dilate_px", 0))
        if marker_dilate > 0:
            marker = morphology.binary_dilation(marker, morphology.disk(marker_dilate))

    vegetation_dilate = int(vegetation_cfg.get("dilate_px", 0))
    if vegetation_dilate > 0:
        vegetation = morphology.binary_dilation(vegetation, morphology.disk(vegetation_dilate))

    vegetation &= valid_mask
    marker &= valid_mask
    cleanv = valid_mask & (~vegetation) & (~marker)
    return cleanv, vegetation, marker


def statistic_value(values: Sequence[float], statistic: str) -> float:
    values = np.asarray(values, dtype=np.float64)
    values = values[np.isfinite(values)]
    if values.size == 0:
        return np.nan
    statistic = statistic.lower()
    if statistic == "mean":
        return float(np.mean(values))
    if statistic in ("median", "p50"):
        return float(np.median(values))
    if statistic == "std":
        return float(np.std(values, ddof=0))
    if statistic == "cv":
        mean = float(np.mean(values))
        std = float(np.std(values, ddof=0))
        return float(std / (abs(mean) + 1e-10))
    if statistic == "min":
        return float(np.min(values))
    if statistic == "max":
        return float(np.max(values))
    if statistic.startswith("p") and statistic[1:].isdigit():
        return float(np.percentile(values, int(statistic[1:])))
    raise ValueError(f"Unsupported statistic: {statistic}")


def summarize_layer(
    layer: np.ndarray,
    mask: np.ndarray,
    prefix: str,
    statistics: Sequence[str] = SUPPORTED_STATS,
) -> Dict[str, float]:
    values = np.asarray(layer)[mask]
    return {f"{prefix}_{stat}": statistic_value(values, stat) for stat in statistics}


def glcm_features(
    image: np.ndarray,
    mask: np.ndarray,
    prefix: str,
    levels: int = 32,
) -> Dict[str, float]:
    mask = np.asarray(mask, dtype=bool) & np.isfinite(image)
    if int(mask.sum()) < 20:
        return {}
    rows, cols = np.where(mask)
    sub = np.asarray(image, dtype=np.float32)[rows.min():rows.max() + 1, cols.min():cols.max() + 1].copy()
    submask = mask[rows.min():rows.max() + 1, cols.min():cols.max() + 1]
    values = sub[submask]
    low, high = np.percentile(values, [2, 98])
    if high <= low:
        return {}

    quantized = np.clip((sub - low) / (high - low + EPS) * (levels - 1), 0, levels - 1).astype(np.uint8)
    quantized[~submask] = int(np.median(quantized[submask]))
    glcm = graycomatrix(
        quantized,
        distances=[1],
        angles=[0, np.pi / 4, np.pi / 2, 3 * np.pi / 4],
        levels=levels,
        symmetric=True,
        normed=True,
    )

    result: Dict[str, float] = {}
    for prop in ("contrast", "correlation", "energy", "homogeneity", "ASM"):
        result[f"{prefix}_{prop}_mean"] = float(np.nanmean(graycoprops(glcm, prop)))
    probabilities = glcm[:, :, 0, :]
    entropy = -np.sum(probabilities * np.log(probabilities + 1e-12), axis=(0, 1))
    result[f"{prefix}_Entropy_mean"] = float(np.nanmean(entropy))
    return result


def parse_feature_name(feature_name: str) -> Tuple[float, str, str]:
    """Parse ``R0.50m__RGB_Gray_max`` into ROI, layer, and statistic."""
    text = str(feature_name)
    if "__" not in text or not text.startswith("R"):
        raise ValueError(f"Feature lacks an ROI prefix: {feature_name}")
    roi_token, base = text.split("__", 1)
    roi_m = float(roi_token[1:-1])
    for statistic in sorted(SUPPORTED_STATS, key=len, reverse=True):
        suffix = "_" + statistic
        if base.endswith(suffix):
            return roi_m, base[:-len(suffix)], statistic
    raise ValueError(f"Feature lacks a supported statistic suffix: {feature_name}")


def feature_definitions() -> Sequence[FeatureDefinition]:
    """Human-readable pixel-level formula dictionary."""
    return [
        FeatureDefinition("Band_Green", "Multispectral Green", "G", "Green-band reflectance."),
        FeatureDefinition("Band_Red", "Multispectral Red", "R", "Red-band reflectance."),
        FeatureDefinition("Band_RedEdge", "Multispectral RedEdge", "RE", "Red-edge reflectance."),
        FeatureDefinition("Band_NIR", "Multispectral NIR", "N", "Near-infrared reflectance."),
        FeatureDefinition("MS_Brightness", "Multispectral", "(G + R + RE + N) / 4", "Mean four-band brightness."),
        FeatureDefinition("Visible_Brightness_GR", "Multispectral Green and Red", "(G + R) / 2", "Visible Green--Red brightness."),
        FeatureDefinition("Redness_RG", "Multispectral Red and Green", "(R - G) / (R + G + eps)", "Normalized Red--Green redness."),
        FeatureDefinition("RGB_R_raw", "RGB camera", "R_rgb", "RGB red-channel value."),
        FeatureDefinition("RGB_G_raw", "RGB camera", "G_rgb", "RGB green-channel value."),
        FeatureDefinition("RGB_B_raw", "RGB camera", "B_rgb", "RGB blue-channel value."),
        FeatureDefinition("RGB_Gray", "RGB camera", "(R_rgb + G_rgb + B_rgb) / 3", "RGB grayscale brightness."),
        FeatureDefinition("RGB_r_chroma", "RGB camera", "R_rgb / (R_rgb + G_rgb + B_rgb + eps)", "Red chromaticity."),
        FeatureDefinition("RGB_g_chroma", "RGB camera", "G_rgb / (R_rgb + G_rgb + B_rgb + eps)", "Green chromaticity."),
        FeatureDefinition("RGB_b_chroma", "RGB camera", "B_rgb / (R_rgb + G_rgb + B_rgb + eps)", "Blue chromaticity."),
        FeatureDefinition("RGB_ExG", "RGB camera", "2g - r - b", "Excess-green index."),
        FeatureDefinition("RGB_ExR", "RGB camera", "1.4r - g", "Excess-red index."),
        FeatureDefinition("RGB_ExB", "RGB camera", "1.4b - g", "Excess-blue index."),
        FeatureDefinition("RGB_ExGR", "RGB camera", "ExG - ExR", "Excess-green minus excess-red."),
        FeatureDefinition("RGB_NGRDI", "RGB camera", "(G_rgb - R_rgb) / (G_rgb + R_rgb + eps)", "Normalized Green--Red difference."),
        FeatureDefinition("RGB_VARI", "RGB camera", "(G_rgb - R_rgb) / (G_rgb + R_rgb - B_rgb + eps)", "Visible atmospherically resistant index."),
        FeatureDefinition("RGB_RGBVI", "RGB camera", "(G_rgb^2 - R_rgb B_rgb) / (G_rgb^2 + R_rgb B_rgb + eps)", "RGB vegetation index."),
        FeatureDefinition("NDVI", "Multispectral", "(N - R) / (N + R + eps)", "Normalized difference vegetation index."),
        FeatureDefinition("GNDVI", "Multispectral", "(N - G) / (N + G + eps)", "Green normalized difference vegetation index."),
        FeatureDefinition("NDRE", "Multispectral", "(N - RE) / (N + RE + eps)", "Normalized difference red-edge index."),
        FeatureDefinition("RVI", "Multispectral", "N / (R + eps)", "Ratio vegetation index."),
        FeatureDefinition("DVI", "Multispectral", "N - R", "Difference vegetation index."),
        FeatureDefinition("OSAVI", "Multispectral", "1.16(N - R) / (N + R + 0.16 + eps)", "Optimized soil-adjusted vegetation index."),
        FeatureDefinition("Log_<Band>", "Multispectral", "ln(max(Band, eps))", "Natural-log band transform."),
        FeatureDefinition("Sqrt_<Band>", "Multispectral", "sqrt(max(Band, eps))", "Square-root band transform."),
    ]


def formula_reference_table() -> pd.DataFrame:
    rows = [definition.__dict__ for definition in feature_definitions()]
    for stat in SUPPORTED_STATS:
        if stat == "mean":
            formula = "mean(x_i)"
        elif stat in ("median", "p50"):
            formula = "median(x_i)"
        elif stat == "std":
            formula = "sqrt(mean((x_i - mean(x_i))^2))"
        elif stat == "cv":
            formula = "std(x_i) / (abs(mean(x_i)) + 1e-10)"
        elif stat == "min":
            formula = "min(x_i)"
        elif stat == "max":
            formula = "max(x_i)"
        else:
            formula = f"{stat[1:]}th percentile of x_i"
        rows.append({
            "name": f"ROI statistic: {stat}",
            "source": "CleanV-retained pixels within the selected ROI",
            "formula": formula,
            "description": "ROI-level summary appended to a pixel-layer name.",
            "unit": "inherits the pixel-layer unit; CV is dimensionless",
        })
    return pd.DataFrame(rows)


if __name__ == "__main__":
    output = "feature_formula_reference.csv"
    formula_reference_table().to_csv(output, index=False, encoding="utf-8-sig")
    print(f"Saved: {output}")
