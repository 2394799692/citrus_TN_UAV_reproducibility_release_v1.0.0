# Validation record

**Validation rechecked for public release v1.0.0: 2 September 2026.**

The following command was executed from the repository root:

```bash
python scripts/06_reproduce_final_gbdt.py
```

Observed result in the validation environment:

| Metric | Value |
|---|---:|
| Sample N | 50 |
| Feature N | 5 |
| NNDM R² | 0.771065 |
| RMSE | 122.403885 mg kg⁻¹ |
| RMSE | 0.122404 g kg⁻¹ |
| MAE | 97.272625 mg kg⁻¹ |
| MAE | 0.097273 g kg⁻¹ |
| RPD | 2.111207 |
| Mean retained training N | 48.86 |
| Minimum retained training N | 46 |

All Python files passed `python -m compileall scripts`. The final GBDT reproduction uses the archived anonymised NNDM fold plan distributed with the repository.
