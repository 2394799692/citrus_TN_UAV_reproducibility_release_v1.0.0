# Current compact TN reproduction data

This directory contains the anonymised five-feature TN modelling table, the final GBDT parameters, the final feature definitions, the six-model result summary, and the archived NNDM fold plan used for the manuscript.

Run from the repository root:

```bash
python scripts/06_reproduce_final_gbdt.py
```

The expected final GBDT result is approximately:

```text
NNDM R² = 0.771065
RMSE = 0.122404 g kg⁻¹
MAE = 0.097273 g kg⁻¹
RPD = 2.111207
```

The sample identifiers and fold memberships are anonymised. Raw RTK coordinates and the complete prediction grid are not distributed.
