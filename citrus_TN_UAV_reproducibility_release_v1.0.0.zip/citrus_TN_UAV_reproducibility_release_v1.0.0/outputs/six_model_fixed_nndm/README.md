# Six-model fixed-parameter NNDM outputs

`expected_manuscript_summary.csv` records the final values reported in the manuscript.

Run:

```bash
python scripts/07_six_model_nndm_fixed_parameters.py
```

to generate the sample-level NNDM predictions and a fresh summary under the current software environment.
