# Package changelog

## v1.0.0 — first public release (2026-09-02)

This is the first public GitHub release of the reproducibility package. The related Chinese invention patent application “果园裸土土壤 TN 预测方法及装置” (Application No. 202611253944.9) has an application date of 18 August 2026 and was accepted by CNIPA before this public release.

This release aligns the reproducibility package with the validation sequence described in the associated manuscript.

Main changes:

- retained random five-fold cross-validation only for preliminary feature screening and candidate-range narrowing;
- changed formal feature-subset reassessment and local refinement in `scripts/02_feature_screening_selection.py` from NNDM to conventional LOOCV;
- changed the fixed-feature Raw–CleanV comparison in script 02 to conventional LOOCV;
- added LOOCV-based single-scale ROI and feature-category ablation outputs to script 02;
- introduced prediction-domain-oriented NNDM only after the feature configuration is fixed, beginning with `scripts/03_model_training_and_comparison.py`;
- retained NNDM for algorithm and shortlisted hyperparameter comparison, final model selection, and primary spatial-performance assessment;
- retained repeated ten-fold cross-validation only as a complementary sensitivity analysis;
- updated README and NNDM documentation to remove statements that feature selection or TN ablations use NNDM.

The archived anonymised NNDM fold plan and the final GBDT/six-model reproduction scripts are unchanged because they correspond to the manuscript's Section 3.3 model-comparison stage.

## CleanV manuscript-alignment update

- restored the manuscript-stated strong-vegetation thresholds to NDVI > 0.35, GNDVI > 0.32, and NDRE > 0.25;
- changed the strong multispectral vegetation rule from alternative OR branches to simultaneous satisfaction of all three thresholds;
- enabled one-pixel morphological dilation of the vegetation mask, consistent with the manuscript description;
- updated the README to document the manuscript-specific CleanV settings.
- documented that the exact original brightness threshold for deep-shadow screening is not recoverable from the archived release configuration; no replacement threshold was invented.
