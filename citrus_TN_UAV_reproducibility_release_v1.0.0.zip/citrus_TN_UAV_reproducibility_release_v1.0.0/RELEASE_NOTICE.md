# Public release and patent chronology

This file records the provenance of the first public GitHub release of this reproducibility package.

## Related patent application

- **Official Chinese title:** 果园裸土土壤 TN 预测方法及装置
- **Application number:** 202611253944.9
- **Application date:** 18 August 2026
- **CNIPA acceptance notice issue date:** 18 August 2026
- **Applicants:** Institute of Agricultural Resources and Regional Planning, Chinese Academy of Agricultural Sciences; Citrus Research Institute, Southwest University
- **Status before this repository was made public:** accepted by the China National Intellectual Property Administration (CNIPA)

## Public software release

- **Version:** v1.0.0
- **First public GitHub release:** 2 September 2026

The code was developed before 2 September 2026. The date above records the first public GitHub release of this code package and is provided to distinguish public disclosure from earlier private development and manuscript-preparation use. The patent application date and the CNIPA acceptance notice issue date are both 18 August 2026, preceding the first public GitHub release.

The inclusion of this chronology does not state or imply that the patent has been granted, and it does not grant any patent or software licence. No patent-application PDF is included in this public repository.
